MISE EN LIGNE DE LA PAGE DE VENTE
=================================

Ce dossier est pret a etre heberge TEL QUEL.
Ne renommez rien, ne deplacez rien : les chemins sont relatifs.

DEUX FICHIERS IMPORTANTS
  index.html   -> la page de vente (page d'accueil)
  merci.html   -> la page apres achat

HEBERGEMENT GRATUIT — 3 OPTIONS

1) NETLIFY DROP (le plus rapide, 2 minutes)
   - Allez sur app.netlify.com/drop
   - Glissez ce dossier entier dans la page
   - Vous obtenez une URL du type https://xxxx.netlify.app
   - Puis Site settings > Domain management pour renommer

2) CLOUDFLARE PAGES
   - dash.cloudflare.com > Workers & Pages > Create > Pages
   - "Upload assets" > glissez ce dossier
   - URL https://xxxx.pages.dev

3) GITHUB PAGES (si vous gardez le repo)
   - Settings > Pages > Source: Deploy from a branch
   - Branch: arena/5faa1edd-tt00crm / folder: / (root)
   - URL: https://supperdevloper-oss.github.io/tt00crm/france/

APRES LA MISE EN LIGNE
  - Verifiez que les images s'affichent
  - Verifiez que le bouton ouvre bien Gumroad
  - Mettez cette URL dans votre annonce Facebook
  - Dans Gumroad > Settings, mettez merci.html comme page de redirection
    apres achat (Content > "Redirect to" ou Settings > Advanced)
