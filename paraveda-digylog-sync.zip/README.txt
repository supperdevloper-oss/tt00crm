PARAVEDA DIGYLOG SYNC

1. Extract this ZIP on your computer.
2. Upload api.php to public_html and replace the old api.php.
3. Upload digylog-admin.html to public_html and replace the wrong file.
4. Do not rename either file.

Expected files:
- api.php
- digylog-admin.html
