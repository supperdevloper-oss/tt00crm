Paraveda - Digylog safe phone matching and emergency rollback

Upload ALL THREE files to public_html:
- api.php
- index.html
- digylog-admin.html

URGENT RECOVERY:
Open digylog-admin.html and click the red emergency rollback button. It first previews recoverable rows, asks for confirmation, then restores only fields written by the previous phone-matching operation from pre-write backups. Manual corrections made later are preserved.

Safety fix:
- A phone number alone can never link an order.
- Linking requires an exact order date plus another matching field and a unique best candidate.
- Phone matching writes Tracking only; it never changes livraison or dateLiv.
- Delivery status is updated separately using the confirmed tracking endpoint.
