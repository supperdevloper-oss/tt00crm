Paraveda - Digylog automatic sync + visible Tracking column

Upload ALL THREE files to public_html and replace the old copies:
- api.php
- index.html
- digylog-admin.html

Then:
1. Open https://paraveda.store/digylog-admin.html as admin.
2. Click "مزامنة جميع طلبيات Digylog دابا" once and keep the page open.
3. Reload the CRM with Ctrl+F5.

The CRM now shows a Tracking column in COMONDES and LIVRAISON. It discovers hidden Digylog trackings, matches by phone/name/city/date/price, and stores them even for non-final statuses such as Expédier vers. Future orders are linked automatically.
