Paraveda CRM — original code restoration

This package restores api.php, index.html, and digylog-admin.html directly from the original "para vida.zip" committed before the Arena changes.

Only two safety changes are applied to the original code:
1. The inbound Digylog webhook is acknowledged but cannot modify CRM rows (no automatic Livrée/Retour/Tracking/dateLiv updates).
2. The device clock-difference warning remains removed.

The package does not contain crm_data.json and therefore does not overwrite current CRM data.

Upload all three files to public_html and hard-refresh the CRM.
