Paraveda - Digylog tracking repair

Upload ALL THREE files to public_html and replace old copies:
- api.php
- index.html
- digylog-admin.html

For existing rows incorrectly marked "Expédier vers" without Tracking:
1. Open digylog-admin.html as admin.
2. Click "إصلاح Expédier vers اللي بلا Tracking" once.
3. The repair resubmits the same merchant order numbers with checkDuplicate=1 and only writes a value when Digylog explicitly returns a tracking number.
4. Reload CRM with Ctrl+F5.

For future orders, CRM no longer marks a row Expédier vers from batch HTTP 200 alone; a per-order tracking number is required.
