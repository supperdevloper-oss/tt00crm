Paraveda - Digylog seller phone search

Upload ALL THREE files to public_html:
- api.php
- index.html
- digylog-admin.html

The exact Seller endpoint discovered from the browser is:
GET https://api.digylog.com/api/seller/v48/historic/orders?phone=...&datatype=1&countPerPage=100&currentPage=1&sort=0

In digylog-admin.html, paste the temporary Seller Authorization value into the Seller Session Token field (never into chat), save, then click the blue phone matching button. The token is automatically deleted from the CRM server after successful completion. Log out and back into Digylog afterwards to rotate the browser session.
