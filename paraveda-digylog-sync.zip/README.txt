Paraveda - definitive Digylog phone-match rollback

Upload api.php (and digylog-admin.html if not already installed).
The red rollback now locates the first successful unsafe phone-match in audit.log, selects the newest backup created before it, identifies every affected order from later snapshots, and restores tracking/status/delivery date from that single clean baseline with new authoritative timestamps.
