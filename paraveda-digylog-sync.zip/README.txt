Paraveda - Digylog seller phone search

Upload ALL THREE files to public_html:
- api.php
- index.html
- digylog-admin.html

In digylog-admin.html, paste the temporary Seller Authorization value into the Seller Session Token field and click the blue phone matching button DIRECTLY. Saving is no longer required; the token is sent only with the matching operation and is not written to config.

Exact endpoint:
GET https://api.digylog.com/api/seller/v48/historic/orders?phone=...&datatype=1&countPerPage=100&currentPage=1&sort=0
