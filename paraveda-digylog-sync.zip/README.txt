Paraveda - Digylog full Tracking discovery

Upload ALL THREE files to public_html and replace the old copies:
- api.php
- index.html
- digylog-admin.html

Open digylog-admin.html and click the green bulk synchronization button once. This version queries the connected Digylog API directly using supported pagination variants, merges remote trackings with locally known ones, fetches each order's details, and matches CRM rows by phone/name/city/date/price.
