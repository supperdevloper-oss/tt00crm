Paraveda - Digylog reverse phone matching

Upload ALL THREE files to public_html:
- api.php
- index.html
- digylog-admin.html

Open digylog-admin.html, hard refresh, and click the blue button:
"جلب Tracking بمطابقة أرقام الهاتف"

The server collects unlinked CRM phone numbers, queries the connected Digylog API using known phone-search route variants, validates an exact normalized phone match, disambiguates duplicates by date/price/city/name, then writes Tracking and final delivery status back to CRM.
