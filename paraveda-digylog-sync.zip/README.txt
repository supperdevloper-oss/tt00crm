Paraveda - Digylog automatic status sync

Upload BOTH files to public_html and replace the old copies:
- api.php
- digylog-admin.html

Then open https://paraveda.store/digylog-admin.html as admin.
Use "مزامنة جميع طلبيات Digylog دابا" once for existing orders.
No visible tracking column is required: the system discovers hidden trackings from saved Digylog responses and webhook logs, then matches CRM orders by phone, name, city, date, and price.
Future Livrée / Retournée updates are automatic through webhook, with a cron polling fallback.
