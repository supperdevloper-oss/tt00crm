Paraveda emergency correction

Upload api.php and digylog-admin.html.
The red action now does exactly one targeted correction: among orders proven affected by the unsafe phone-match, only orders whose clean pre-incident baseline status was Expédier vers are set back to Expédier vers. Their wrong tracking, Digylog status and dateLiv are cleared so automatic reconciliation cannot turn them back to Livrée. The server re-reads and verifies the saved result and reports verifiedExpedier, stillLivree, targeted, and writeOk.
