<?php
/**
 * Paraveda CRM — api.php (v3.82)
 *
 * Contract used by index.html (unchanged):
 *   GET  api.php                       → { key: {t, d}, ... }
 *   POST api.php {key, t, d}           → {ok:true, t:<effective t>}   (header X-Sync-Token required)
 *
 * v3.99 — إشعار أوتوماتيك ملي تدخل/تتبدل طلبية باسم بنت (CRM + الشيت)
 * v3.98 — توزيع الطلبيات الجداد على: Meryam → AYA → imane → safa (بالدور) + ID ديما = 1
 * v3.97 — الشيت → CRM: POST {action:'sheet_orders', rows:[...]} كيزيد الطلبيات الجداد
 *   (تكرار سيرفر-سايد: تاريخ + هاتف + منتوج). الجبد الكامل من CRM ما تبدلش.
 *
 * v3.82 — التسليك النهائي: تغيير الباسوورد كيوصل للسيرفر + يوزر ممسوح ما كيرجعش
 *   + المتصفح كيعاود يصيفط اليوزرز/الطلبيات إلا لقا السيرفر راهو رجع لنسخة قديمة.
 *   POST api.php {action: ...}         → Digylog actions  (header X-Sync-Token required)
 *
 * v3.81 — الإصلاح الجذري ديال "اليوزر الجديد كيتمسح من بعد لحضات":
 *   - journal replay ولى كيقارن الوقت: سطر قديم عمرُو ما كيقدر يتربح على داتا أحدث
 *     منه (v3.80 كانت كتطبق آخر سطر ديما — سطر قديم فـ journal الميرا كان كيمسح
 *     اليوزرز/الطلبيات فكل قرية).
 *   - قرية الملفات: primary + mirror كيتدمجو مفتاح بمفتاح (الأحدث كيربح)، واليوزرز
 *     كيتوحّدو بالـ id — ملف قديم فـ أي بلاصة ما بقاش كيخبي يوزرز.
 *   - t ديال أي مفتاح ما كينقصش عمرو (noop:same كان كيرجّع الوقت للور مع ساعة
 *     متأخرة → الأجهزة الأخرى كيوقفو يشوفو التبدلات).
 *   - POST كيرجّع t الفعلي → المتصفح كيسجلو → كلشي متزامن مع ساعة السيرفر.
 *   - فشل الكتابة فـ journal/MIRA كيتسجل فـ audit.log (ما بقاش صامت).
 *
 * v3.41 hardening:
 *   - key whitelist (only known CRM keys are accepted)
 *   - stale-write rejection (older `t` than stored never overwrites newer data)
 *   - unwrap protection (rejects double-wrapped {t,d:{t,d}} payloads → fixes corrupted custom_sheets / team_photos)
 *   - exclusive lock around read-modify-write (two agents saving at once no longer lose a write)
 *   - rotating backups (last 30 writes + 1 per day) instead of a single .backup that got overwritten
 *   - payload size limit + minimal audit log
 *   - data dir outside public_html when available (../crm-paraveda-data), falls back to local file
 */
error_reporting(E_ALL);
ini_set('display_errors', '0');

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, X-Sync-Token');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') { exit; }

/* ---------- config ---------- */
$SECRET = '8c907fc0f4ffe0b9775a6b7c3c0fc7700e5724c0d78343df';

/* v3.67: deterministic data dir + mirror.
 * قبل: كان كيبدل المجلد بصمت إلا كان !is_writable → جوج ملفات بيانات مفروشين =
 * طلبيات كتظهر وكتختفي. دابا: كنختارو المجلد بالـ epoch (أحدث بيانات) ونكتبو
 * فـ الجوج بلاصات ديما حتى يرجع التوأمية بيناتهم. */
$DIR_EXT = __DIR__ . '/../crm-paraveda-data';
$DIR_LOC = __DIR__;
function crm_epoch_dir($d) {
  $m = 0;
  $s = @file_get_contents($d . '/crm_data.json');
  if ($s !== false && $s !== '') {
    $j = json_decode($s, true);
    if (is_array($j)) { foreach ($j as $v) { if (is_array($v) && isset($v['t']) && (int)$v['t'] > $m) $m = (int)$v['t']; } }
    else { $m = -1; } // undecodable file must never win
  }
  foreach (array($d . '/journal.log', $d . '/journal.log.1') as $jf) {
    if (!file_exists($jf)) continue;
    $fh = @fopen($jf, 'r'); if (!$fh) continue;
    $sz = @filesize($jf); if ($sz > 8192) @fseek($fh, -8192, SEEK_END);
    $tail = '';
    while (($l = fgets($fh)) !== false) { $l = trim($l); if ($l !== '') $tail = $l; }
    @fclose($fh);
    $e = json_decode((string)$tail, true);
    if (is_array($e) && isset($e['t']) && (int)$e['t'] > $m) $m = (int)$e['t'];
  }
  return $m;
}
$PRIMARY = $DIR_EXT; $MIRROR = $DIR_LOC;
$__eE = 0; $__eL = 0;
if (!is_dir($DIR_EXT)) { $PRIMARY = $DIR_LOC; $MIRROR = null; }
else {
  $__eE = crm_epoch_dir($DIR_EXT); $__eL = crm_epoch_dir($DIR_LOC);
  if ($__eL > $__eE) { $PRIMARY = $DIR_LOC; $MIRROR = $DIR_EXT; }
}
$DATA_DIR    = $PRIMARY;
$DATA_FILE   = $PRIMARY . '/crm_data.json';
$MIRROR_FILE = ($MIRROR !== null) ? $MIRROR . '/crm_data.json' : null;
$LOCK_FILE   = $PRIMARY . '/.crm.lock';
$BACKUP_DIR  = $PRIMARY . '/backups';
$AUDIT_FILE  = $PRIMARY . '/audit.log';
$JOURNAL     = $PRIMARY . '/journal.log';
$JOURNAL_M   = ($MIRROR !== null) ? $MIRROR . '/journal.log' : null;
$PUSH_KEYS_FILE = $DATA_DIR . '/push_keys.json';   // v3.98: مفاتيح Web Push (مسدودة من الويب)
$PUSH_SUBS_FILE = $DATA_DIR . '/push_subs.json';   // v3.98: هواتف البنات (مسدودة من الويب)
/* PERF v3.90: 8MB journal = replay ديال 8 ميغا JSON فـ كل قراية. 512KB كافيين
 * بزاف حيت كل كتابة كتسبقها كتابة كاملة ديال crm_data.json تحت القفل. */
$JOURNAL_MAX = 512 * 1024;
$MAX_BODY    = 24 * 1024 * 1024;   // 24 MB per write
$KEEP_WRITES = 30;                 // rotating pre-write backups
$KEEP_DAYS   = 30;                 // daily snapshots
$ETAG_CACHE  = $PRIMARY . '/.crm.etag';   // PERF v3.90: cache ديال ETag باش GET يولي 304 بلا قراية
$BACKUP_MIN_GAP = 120;             // PERF v3.90: نسخة احتياطية كل دقيقتين كحد أقصى (ماشي فكل كتابة)
$TOMBSTONE_TTL  = 21 * 86400;      // PERF v3.90: الطلبية الممسوحة كتتنحا نهائياً من بعد 21 يوم
$TOMBSTONE_MAX  = 150;             // PERF v3.90: وفأي حال، ما كنحتافظوش بأكثر من 150 طومبستون

$ALLOWED_KEYS = array(
  'paraveda_users_v1','paraveda_orders_v5','paraveda_agent_names_v1','paraveda_chat_v1',
  'paraveda_worktimes_v1','paraveda_remarques_v1','paraveda_avances_v1','paraveda_adspend_v1',
  'paraveda_perfrows_v1','paraveda_livraison_v1','paraveda_history_v1','paraveda_villes_v2',
  'paraveda_catalog_v1','sheet_pièce','paraveda_team_photos_v1','tabs_list_v1',
  'custom_sheets_v1','paraveda_period_v1','paraveda_period_v2',
  'paraveda_backup_v1','paraveda_backup_v1_agents',
  'paraveda_dupok_v1'   // v3.94: المكررات لي تعلّمات «ماشي مكررة»
);

/* ---------- helpers ---------- */
function crm_token() {
  if (isset($_SERVER['HTTP_X_SYNC_TOKEN'])) return (string)$_SERVER['HTTP_X_SYNC_TOKEN'];
  if (isset($_GET['token'])) return (string)$_GET['token'];
  return '';
}
function crm_out($arr, $code = 200) {
  if ($code !== 200) http_response_code($code);
  echo json_encode($arr, JSON_UNESCAPED_UNICODE);
  exit;
}
function crm_audit($line) {
  global $AUDIT_FILE;
  $ip = $_SERVER['REMOTE_ADDR'] ?? '-';
  @file_put_contents($AUDIT_FILE, date('Y-m-d H:i:s') . " | $ip | $line\n", FILE_APPEND | LOCK_EX);
  if (@filesize($AUDIT_FILE) > 2 * 1024 * 1024) { @rename($AUDIT_FILE, $AUDIT_FILE . '.1'); }
}
/** v3.41: afrizon_* → paraveda_* (rename), keeps newest if both exist */
function crm_migrate_keys($j) {
  $o = array();
  foreach ($j as $k => $v) {
    $nk = (strpos($k, 'afrizon_') === 0) ? 'paraveda_' . substr($k, 8) : $k;
    if (isset($o[$nk]) && isset($o[$nk]['t']) && isset($v['t']) && $o[$nk]['t'] >= $v['t']) continue;
    $o[$nk] = $v;
  }
  return $o;
}
/* PERF v3.90: crm_read_raw() كانت كتتسما 3 مرات فـ كل POST — كل مرة كتقرا وتفكّك
 * crm_data.json (1.1MB) + الميرا (1.1MB) + replay ديال 4 ملفات journal.
 * = أكثر من 10MB ديال JSON decoding باش تحفظ طلبية وحدة.
 * دابا النتيجة كتتخزن فالذاكرة داخل نفس الـ request. القراية لي تحت القفل
 * خاصها تكون طرية ($force=true) حيت ممكن شي request آخر كتب بيناتهم. */
function crm_read_raw($force = false) {
  static $cache = null;
  if (!$force && $cache !== null) return $cache;
  $cache = crm_read_raw_fresh();
  return $cache;
}
function crm_read_raw_fresh() {
  global $DATA_FILE, $BACKUP_DIR, $MIRROR_FILE;
  $j = null;
  if (file_exists($DATA_FILE)) {
    $s = @file_get_contents($DATA_FILE);
    $j = json_decode((string)$s, true);
    if (!is_array($j)) crm_audit("corrupt | main file undecodable | len=" . strlen((string)$s));
  }
  if (!is_array($j)) {
    // corrupted/missing main file → try newest backup (journal replay below restores newest state anyway)
    $c = glob($BACKUP_DIR . '/b-*.json');
    if ($c) { rsort($c); foreach ($c as $f) { $j = json_decode((string)@file_get_contents($f), true); if (is_array($j)) { crm_audit("recover | from=" . basename($f)); break; } } }
  }
  if (!is_array($j)) $j = array();
  /* v3.81: دمج primary + mirror مفتاح بمفتاح (الأحدث t كيربح) + توحيد اليوزرز بالـ id.
     قبل: إلا الميرا (crm-paraveda-data) كانت فيها نسخة قديمة، كل قرية كترجع للقديم
     → "اليوزر الجديد كيتمسح من بعد لحضات". دابا ملف قديم فأي بلاصة ما كيقدر
     يخبي داتا أحدث، واليوزرز لي ضاعو من أحد الملفين كيرجعو. */
  if ($MIRROR_FILE && is_file($MIRROR_FILE)) {
    $m = json_decode((string)@file_get_contents($MIRROR_FILE), true);
    if (is_array($m)) {
      /* v3.82: ليستة اليوزرز ديال الملف الرئيسي خاصها تنحفظ قبل دمج المفاتيح —
         إلا الميرا كان أحدث، الدمج كيبدل اليوزرز ديال الرئيسي قبل الاتحاد
         → اليوزرز لي غير فالرئيسي كانو كيضيعو. */
      $pu = (isset($j['paraveda_users_v1']['d']) && is_array($j['paraveda_users_v1']['d'])) ? crm_unwrap($j['paraveda_users_v1']['d']) : null;
      $mirrorOlderKeys = 0;
      foreach ($m as $mk => $mv) {
        if (!is_array($mv) || !isset($mv['t'])) continue;
        if (!isset($j[$mk]) || !is_array($j[$mk]) || (int)$mv['t'] > (int)$j[$mk]['t']) { $j[$mk] = $mv; $mirrorOlderKeys++; }
      }
      if ($mirrorOlderKeys > 0) crm_audit("mirror-merge | newer-from-mirror keys=$mirrorOlderKeys");
      $ub = (isset($m['paraveda_users_v1']['d']) && is_array($m['paraveda_users_v1']['d'])) ? crm_unwrap($m['paraveda_users_v1']['d']) : null;
      if (is_array($pu) && is_array($ub)) {
        $un = crm_users_union($pu, $ub);
        if (count($un) !== count($pu)) { crm_audit("users-rescue | merged users: " . count($pu) . " + " . count($ub) . " → " . count($un)); $j['paraveda_users_v1']['d'] = $un; $j['paraveda_users_v1']['t'] = max((int)$j['paraveda_users_v1']['t'], (int)$m['paraveda_users_v1']['t']); }
      }
    }
  }
  // v3.67: journal replay — أحدث كتابة ناجحة كتربح ديما، حتى إلا crm_data.json تبدل يدويا
  // (FTP) ولا تخسر → الطلبيات الجديدة عمرهم ما كيتنساو.
  return crm_journal_replay(crm_migrate_keys($j));
}
/* v3.81: توحيد ليستة اليوزرز بالـ id — أحدث _u كيربح (الحذف _del محترم).
   كتستعمل فـ دمج الملفات (primary+mirror) باش يوزر مفقود من ملف واحد يرجع. */
function crm_users_union($a, $b) {
  $out = array();
  foreach ($a as $u) { if (is_array($u) && isset($u['id'])) $out[(string)$u['id']] = $u; }
  foreach ($b as $u) {
    if (!is_array($u) || !isset($u['id'])) continue;
    $id = (string)$u['id'];
    if (!isset($out[$id])) { $out[$id] = $u; continue; }
    /* v3.82: الحذف نهائي — إلا شي نسخة فيهم _del هي لي كتربح (من الجوج جيهات).
       جوج طومبستونات → الأحدث _u كيربح. حي ضد ميت → الميت كيربح ديما. */
    $cd = !empty($out[$id]['_del']); $nd = !empty($u['_del']);
    if ($cd || $nd) {
      $cu = isset($out[$id]['_u']) ? (float)$out[$id]['_u'] : -1;
      $nu = isset($u['_u']) ? (float)$u['_u'] : -1;
      if (!$cd || ($nd && $nu > $cu)) $out[$id] = $u;
      continue;
    }
    $cu = isset($out[$id]['_u']) ? (float)$out[$id]['_u'] : -1;
    $nu = isset($u['_u']) ? (float)$u['_u'] : -1;
    if ($nu > $cu) $out[$id] = $u;
  }
  return array_values($out);
}
/* v3.67: journal (WAL) — كل كتابة ناجحة كتسجل سطر فـ journal.log. القراية كتعاود
 * التسجيلات فوق الملف الأساسي: إلا الملف الأساسي رجع لنسخة قديمة ولا تفسد،
 * أحدث حالة كترجع بوحدها من الـ journal. */
function crm_journal_append($k, $t, $d) {
  global $JOURNAL, $JOURNAL_M, $JOURNAL_MAX;
  $line = json_encode(array('k' => $k, 't' => $t, 'd' => $d), JSON_UNESCAPED_UNICODE);
  if ($line === false) return;
  foreach (array($JOURNAL, $JOURNAL_M) as $jf) {
    if (!$jf) continue;
    // v3.81: الفشل كيتسجل فـ audit.log — قبل كان صامت وماحدش كان كيعرف علاش الداتا كتضيع
    if (@file_put_contents($jf, $line . "\n", FILE_APPEND | LOCK_EX) === false) { crm_audit("journal-fail | $jf"); continue; }
    if (@filesize($jf) > $JOURNAL_MAX) {
      // كل كتابة كتسبقها كتابة كاملة ديال الملف الرئيسي تحت القفل → محتوى الـ journalولى
      // مكرر → نحيدوه حتى ما يثقلش القراية (replay) فالطلبات الجاية.
      @unlink($jf);
    }
  }
}
function crm_journal_replay($data) {
  global $JOURNAL, $JOURNAL_M;
  $files = array($JOURNAL . '.1', $JOURNAL, ($JOURNAL_M !== null ? $JOURNAL_M . '.1' : null), $JOURNAL_M);
  foreach ($files as $jf) {
    if (!$jf || !file_exists($jf)) continue;
    $fh = @fopen($jf, 'r'); if (!$fh) continue;
    while (($l = fgets($fh)) !== false) {
      $l = trim($l); if ($l === '') continue;
      $e = json_decode($l, true);
      if (!is_array($e) || !isset($e['k'], $e['t'], $e['d']) || !is_array($e['d'])) continue;
      $k = (string)$e['k']; $et = (int)$e['t'];
      /* v3.81: سطر الـ journal ما كيقبلش يتربح على داتا أحدث منه.
         v3.80 كانت كتطبق آخر سطر ديما بالترتيب → سطر قديم فـ journal الميرا
         (ولا أي journal متأخر) كان كيمسح اليوزرز/الطلبيات الجداد فكل قرية.
         هادشي هو بالضبط "اليوزر الجديد كيتمسح من بعد لحضات". */
      $cur = (isset($data[$k]) && is_array($data[$k]) && isset($data[$k]['t'])) ? (int)$data[$k]['t'] : 0;
      if ($et <= $cur) continue;
      $data[$k] = array('t' => $et, 'd' => $e['d']);
    }
    @fclose($fh);
  }
  return $data;
}
/** unwrap {t,d:{t,d:X}} → X (defensive: corruption produced by old import.php) */
function crm_unwrap($v) {
  $g = 0;
  while (is_array($v) && isset($v['t']) && array_key_exists('d', $v) && is_numeric($v['t']) && count($v) <= 2 && $g++ < 5) { $v = $v['d']; }
  return $v;
}
/* PERF v3.90: بصمة رخيصة (stat فقط، بلا قراية) ديال كل ملفات الداتا.
 * كتخدم باش نعرفو واش تبدل شي حاجة بلا ما نقراو 2.2MB ديال JSON. */
function crm_data_sig() {
  global $DATA_FILE, $MIRROR_FILE, $JOURNAL, $JOURNAL_M;
  $p = '';
  foreach (array($DATA_FILE, $MIRROR_FILE, $JOURNAL, $JOURNAL_M, $JOURNAL . '.1') as $f) {
    if (!$f) continue;
    $p .= '|' . (@filemtime($f) ?: 0) . ':' . (@filesize($f) ?: 0);
  }
  return md5($p);
}
/* كيرجع الـ ETag المخزن إلا البصمة باقة هي هي، وإلا null (خاصنا نقراو بصح). */
function crm_etag_cached($sig) {
  global $ETAG_CACHE;
  $s = @file_get_contents($ETAG_CACHE);
  if ($s === false || $s === '') return null;
  $j = json_decode($s, true);
  if (!is_array($j) || !isset($j['sig'], $j['etag'])) return null;
  return ($j['sig'] === $sig) ? (string)$j['etag'] : null;
}
function crm_etag_store($sig, $etag) {
  global $ETAG_CACHE;
  @file_put_contents($ETAG_CACHE, json_encode(array('sig' => $sig, 'etag' => $etag)), LOCK_EX);
}

function crm_backup() {
  global $DATA_FILE, $BACKUP_DIR, $KEEP_WRITES, $KEEP_DAYS, $BACKUP_MIN_GAP;
  if (!file_exists($DATA_FILE)) return;
  if (!is_dir($BACKUP_DIR)) @mkdir($BACKUP_DIR, 0755, true);
  if (!is_dir($BACKUP_DIR)) return;
  /* PERF v3.90: قبل، كل كتابة كانت كتنسخ 1.1MB على القرص. مع 10 وكلاء كيخدمو
   * هادشي ميات الميغاوات ديال I/O فالساعة. دابا نسخة كل دقيقتين كحد أقصى —
   * الحماية باقية (الـ journal + الملف الرئيسي + الميرا) والـ I/O نقص ~95%. */
  $last = 0;
  $b0 = glob($BACKUP_DIR . '/b-*.json');
  if ($b0) { foreach ($b0 as $f) { $mt = @filemtime($f); if ($mt > $last) $last = $mt; } }
  if ($last > 0 && (time() - $last) < $BACKUP_MIN_GAP) {
    $daily0 = $BACKUP_DIR . '/d-' . date('Ymd') . '.json';
    if (!file_exists($daily0)) @copy($DATA_FILE, $daily0);
    return;
  }
  @copy($DATA_FILE, $BACKUP_DIR . '/b-' . date('Ymd-His') . '-' . substr((string)microtime(true) * 1000 % 1000, 0, 3) . '.json');
  $daily = $BACKUP_DIR . '/d-' . date('Ymd') . '.json';
  if (!file_exists($daily)) @copy($DATA_FILE, $daily);
  // rotate
  $b = glob($BACKUP_DIR . '/b-*.json'); if ($b && count($b) > $KEEP_WRITES) { sort($b); foreach (array_slice($b, 0, count($b) - $KEEP_WRITES) as $f) @unlink($f); }
  $d = glob($BACKUP_DIR . '/d-*.json'); if ($d && count($d) > $KEEP_DAYS)   { sort($d); foreach (array_slice($d, 0, count($d) - $KEEP_DAYS) as $f) @unlink($f); }
}
// v3.65: field-level merge — a field edited later (per-field stamp _f) is never overwritten
// by a whole-row write coming from a browser that still held an older copy of the row.
// v3.66: DATE LOCK — dateCreation / dateConfirmation / dateExp / dateLiv can only change
// when the incoming row carries a STRICTLY NEWER per-field stamp (_f.date*). A whole-row
// write from an old/stale browser (no _f, or older _f) can never move a date anymore —
// the stored value always wins. This is the server side of "التاريخ ما كيتبدلش بوحدو".
function crm_merge_row($a, $b) {
  $ua = isset($a['_u']) ? (float)$a['_u'] : 0; $ub = isset($b['_u']) ? (float)$b['_u'] : 0;
  $base = $ub >= $ua ? $b : $a; $oth = $ub >= $ua ? $a : $b;
  if (!empty($a['_del']) || !empty($b['_del'])) return !empty($a['_del']) ? $a : $b;   // v3.103: الحذف نهائي (المسوح ما كيرجعش)
  $bf = (isset($base['_f']) && is_array($base['_f'])) ? $base['_f'] : array();
  $of = (isset($oth['_f']) && is_array($oth['_f'])) ? $oth['_f'] : array();
  foreach ($of as $k => $to) {
    $to = (float)$to; $tb = isset($bf[$k]) ? (float)$bf[$k] : 0;
    if ($to > $tb && array_key_exists($k, $oth)) { $base[$k] = $oth[$k]; $bf[$k] = $to; }
  }
  if ($bf) $base['_f'] = $bf;
  // v3.66 date lock: $a is the STORED row (crm_merge_orders always calls with stored first).
  // If the value differs and the incoming side has no strictly newer explicit date edit,
  // restore the stored value (and its stamp).
  foreach (array('dateCreation','dateConfirmation','dateExp','dateLiv') as $dk) {
    if (!array_key_exists($dk, $a)) continue;
    $av = (string)$a[$dk];
    $bv = array_key_exists($dk, $b) ? (string)$b[$dk] : '';
    if ($av === $bv) continue;
    $ta = (isset($a['_f'][$dk]) && is_numeric($a['_f'][$dk])) ? (float)$a['_f'][$dk] : 0;
    $tb = (isset($b['_f'][$dk]) && is_numeric($b['_f'][$dk])) ? (float)$b['_f'][$dk] : 0;
    if ($tb <= $ta) {
      $base[$dk] = $av;
      if ($ta > 0) {
        $f0 = (isset($base['_f']) && is_array($base['_f'])) ? $base['_f'] : array();
        $f0[$dk] = $ta; $base['_f'] = $f0;
      }
    }
  }
  return $base;
}
function crm_merge_orders($cur, $in, $reset = 0) {
  $nowms = (int)(microtime(true) * 1000);
  $byId = array(); $order = array();
  foreach ($cur as $o) { if (!is_array($o) || !isset($o['id'])) continue; $id = (string)$o['id']; $byId[$id] = $o; $order[] = $id; }
  foreach ($in as $o) {
    if (!is_array($o) || !isset($o['id'])) continue;
    // v3.66: clamp future stamps (device clock ahead of server) — a client can never
    // win a merge just because its clock is wrong; _u and every _f stamp are capped at server time.
    if (isset($o['_u']) && (float)$o['_u'] > $nowms) { $o['_u'] = $nowms; }
    if (isset($o['_f']) && is_array($o['_f'])) {
      foreach ($o['_f'] as $fk => $ft) { if (is_numeric($ft) && (float)$ft > $nowms) $o['_f'][$fk] = $nowms; }
    }
    $id = (string)$o['id'];
    $beforeDates = array();
    if (isset($byId[$id])) {
      foreach (array('dateCreation','dateConfirmation') as $dk) { $beforeDates[$dk] = isset($byId[$id][$dk]) ? (string)$byId[$id][$dk] : ''; }
    }
    if (!isset($byId[$id])) {
      // v3.62: rows older than the last reset (coming from a stale browser cache) are never resurrected
      $u = isset($o['_u']) ? (float)$o['_u'] : 0;
      if ($reset > 0 && $u < $reset) continue;
      $byId[$id] = $o; $order[] = $id; continue;
    }
    $byId[$id] = crm_merge_row($byId[$id], $o);
    // v3.66 audit: every time a merge actually moves a date, leave a trace in audit.log
    foreach ($beforeDates as $dk => $bv) {
      $av = isset($byId[$id][$dk]) ? (string)$byId[$id][$dk] : '';
      if ($bv !== '' && $av !== $bv) crm_audit("date-change | id=$id | $dk: $bv → $av");
    }
  }
  $out = array(); foreach (array_unique($order) as $id) $out[] = $byId[$id];
  usort($out, function($x, $y) { $a = (float)$x['id']; $b = (float)$y['id']; return $a == $b ? 0 : ($a < $b ? 1 : -1); });
  return $out;
}
/* v3.78: دمج موحد — كتابة أحدث كتربح (حتى الحذف)، كتابة متأخرة كتزيد غير الناقص.
   هذا لي كيمنع اختفاء اليوزر الجديد ملي ساعة الجهاز متأخرة ولا جوج زادو فنفس اللحظة. */
function crm_row_key($row) {
  if (is_array($row) && isset($row['id'])) return 'i:' . (string)$row['id'];
  if (is_scalar($row)) return 's:' . (string)$row;
  return 'j:' . json_encode($row);
}
/* PERF v3.90: تنقية الـ tombstones.
 * 599 طلبية من 1408 (42%) كانو عندهم _del=true وباقين فالداتا للأبد — كيتحملو
 * كل مزامنة، كيتدمجو صف بصف، وكياخدو بلاصة فـ localStorage.
 * دابا أي طلبية ممسوحة وقديمة بأكثر من 30 يوم كتتنحا نهائياً. 30 يوم أوسع بزاف
 * من الـ grace ديال المتصفح (15 دقيقة) إذن ما كاين حتى خطر ديال الرجوع. */
function crm_purge_tombstones($rows, $ttl, $max) {
  /* v3.103: الطلبيات الممسوحة ما كتتمسحش نهائياً — كانت كترجع من بعد شي مدة
   * (المتصفح كيرجع نسخة قديمة + الحذف كان كيطيح بعد 150). دابا القديمة كتتصغّر
   * غير (تبقى id + _del + التاريخ/الهاتف/الاسم/المنتوج) باش الحذف يبقى دائم. */
  if (!is_array($rows)) return $rows;
  $cut = ((int)(microtime(true) * 1000)) - ($ttl * 1000);
  $out = array(); $slim = 0;
  foreach ($rows as $r) {
    if (is_array($r) && !empty($r['_del'])) {
      $u = isset($r['_u']) ? (float)$r['_u'] : 0;
      if ($u > 0 && $u < $cut) {
        $r = array(
          'id' => isset($r['id']) ? $r['id'] : '', '_del' => true, '_u' => $u,
          'dateCreation' => isset($r['dateCreation']) ? $r['dateCreation'] : '',
          'telephone' => isset($r['telephone']) ? $r['telephone'] : '',
          'nom' => isset($r['nom']) ? $r['nom'] : '',
          'produit' => isset($r['produit']) ? $r['produit'] : ''
        );
        $slim++;
      }
    }
    $out[] = $r;
  }
  if ($slim > 0) crm_audit("purge | tombstones slimmed=$slim");
  return $out;
}
function crm_merge_list($cur, $in, $tCur, $tIn) {
  if ($tIn >= $tCur) return $in;
  $have = array();
  foreach ($cur as $row) $have[crm_row_key($row)] = true;
  foreach ($in as $row) { $kk = crm_row_key($row); if (!isset($have[$kk])) { $cur[] = $row; $have[$kk] = true; } }
  return $cur;
}
function crm_write($data) {
  global $DATA_FILE;
  $tmp = $DATA_FILE . '.tmp.' . getmypid();
  $json = json_encode($data, JSON_UNESCAPED_UNICODE);
  if ($json === false) return false;
  if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
  if (!@rename($tmp, $DATA_FILE)) { @unlink($tmp); return false; }
  return true;
}
/* v3.67: write primary + mirror — الجوج ملفات ديما متطابقين، ما بقاش split-brain */
function crm_write_all($data) {
  global $MIRROR_FILE;
  $ok = crm_write($data);
  if ($MIRROR_FILE) {
    $tmp = $MIRROR_FILE . '.tmp.' . getmypid();
    $json = json_encode($data, JSON_UNESCAPED_UNICODE);
    if ($json !== false && @file_put_contents($tmp, $json, LOCK_EX) !== false) {
      if (!@rename($tmp, $MIRROR_FILE)) { @unlink($tmp); crm_audit("mirror-fail | rename | $MIRROR_FILE"); } // v3.81: ما بقاش صامت
    } else {
      if (file_exists($tmp)) @unlink($tmp);
      crm_audit("mirror-fail | write | $MIRROR_FILE"); // v3.81: ما بقاش صامت
    }
  }
  return $ok;
}

/* ================================================================
 * v3.98 — إشعارات Web Push للبنات (طلبية جديدة ليها من الشيت)
 *   push_keys.json : مفاتيح VAPID (كتتولد وحدها أول مرة). مسدودة من الويب (.htaccess)
 *   push_subs.json : الهواتف المسجّلة {agent, endpoint, p256dh, auth}. مسدودة من الويب
 *   GET  api.php?pushkey=1&token=...          → المفتاح العام
 *   POST {action:'push_subscribe', agent, sub:{endpoint, keys:{p256dh, auth}}}
 *   POST {action:'push_test', agent}          → إشعار تجريبي لهاد البنت
 *   الإشعارات كتصيفط أوتوماتيك ملي كتدخل طلبيات جداد من الشيت (crm_sheet_orders)
 * ================================================================ */
function crm_push_b64e($s) { return rtrim(strtr(base64_encode($s), '+/', '-_'), '='); }
function crm_push_b64d($s) {
  $s = strtr((string)$s, '-_', '+/');
  return base64_decode($s . str_repeat('=', (4 - strlen($s) % 4) % 4), true);
}
function crm_push_read($file) {
  if (!file_exists($file)) return array();
  $j = json_decode((string)@file_get_contents($file), true);
  return is_array($j) ? $j : array();
}
function crm_push_write($file, $arr) {
  $tmp = $file . '.tmp.' . getmypid();
  $json = json_encode($arr, JSON_UNESCAPED_UNICODE);
  if ($json === false || @file_put_contents($tmp, $json, LOCK_EX) === false) return false;
  if (!@rename($tmp, $file)) { @unlink($tmp); return false; }
  return true;
}
/* نقطة P-256 خام (65 بايت، تبدا بـ 0x04) → مفتاح عام PEM */
function crm_push_pub_from_raw($raw) {
  if (!is_string($raw) || strlen($raw) !== 65 || $raw[0] !== "\x04") return false;
  $der = hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200') . $raw;
  return @openssl_pkey_get_public("-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END PUBLIC KEY-----\n");
}
/* مفتاح EC → نقطة عامة خام 65 بايت */
function crm_push_raw_pub($key) {
  $d = openssl_pkey_get_details($key);
  if (!$d || !isset($d['ec']['x'], $d['ec']['y'])) return false;
  return "\x04" . str_pad($d['ec']['x'], 32, "\x00", STR_PAD_LEFT) . str_pad($d['ec']['y'], 32, "\x00", STR_PAD_LEFT);
}
/* مفاتيح VAPID: كتتقرا من الملف، ولا كتتولد أول مرة */
function crm_push_keys() {
  global $PUSH_KEYS_FILE;
  $k = crm_push_read($PUSH_KEYS_FILE);
  if (!empty($k['priv']) && !empty($k['pub'])) return $k;
  $key = @openssl_pkey_new(array('curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC));
  if (!$key) return null;
  $pem = '';
  if (!openssl_pkey_export($key, $pem)) return null;
  $raw = crm_push_raw_pub($key);
  if ($raw === false) return null;
  $k = array('priv' => $pem, 'pub' => crm_push_b64e($raw));
  return crm_push_write($PUSH_KEYS_FILE, $k) ? $k : null;
}
/* توقيع ECDSA (DER) → 64 بايت خام (r||s) كما يطلب JWT */
function crm_push_der2raw($der) {
  $p = 2;
  if (ord($der[1]) & 0x80) $p = 2 + (ord($der[1]) & 0x7f);
  $rl = ord($der[$p + 1]); $r = substr($der, $p + 2, $rl);
  $p2 = $p + 2 + $rl;
  $sl = ord($der[$p2 + 1]); $s = substr($der, $p2 + 2, $sl);
  return str_pad(ltrim($r, "\x00"), 32, "\x00", STR_PAD_LEFT) . str_pad(ltrim($s, "\x00"), 32, "\x00", STR_PAD_LEFT);
}
/* RFC 8292 (VAPID): Authorization header */
function crm_push_vapid_auth($endpoint) {
  $k = crm_push_keys();
  if (!$k) return null;
  $pk = @openssl_pkey_get_private($k['priv']);
  if (!$pk) return null;
  $p = parse_url($endpoint);
  $aud = $p['scheme'] . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '');
  $h = crm_push_b64e(json_encode(array('typ' => 'JWT', 'alg' => 'ES256')));
  $b = crm_push_b64e(json_encode(array('aud' => $aud, 'exp' => time() + 12 * 3600, 'sub' => 'mailto:admin@paraveda.ma')));
  $in = $h . '.' . $b;
  if (!openssl_sign($in, $der, $pk, OPENSSL_ALGO_SHA256)) return null;
  return 'vapid t=' . $in . '.' . crm_push_b64e(crm_push_der2raw($der)) . ', k=' . $k['pub'];
}
/* RFC 8291: تشفير aes128gcm. $asKey = مفتاح مؤقت جديد لكل رسالة */
function crm_push_encrypt($payload, $uaPub, $auth, $asKey) {
  $asPub = crm_push_raw_pub($asKey);
  $peer  = crm_push_pub_from_raw($uaPub);
  if ($asPub === false || $peer === false || strlen($auth) !== 16) return null;
  $ecdh = openssl_pkey_derive($peer, $asKey, 32);
  if ($ecdh === false) return null;
  $salt    = random_bytes(16);
  $ikm     = hash_hkdf('sha256', $ecdh, 32, "WebPush: info\x00" . $uaPub . $asPub, $auth);
  $cek     = hash_hkdf('sha256', $ikm, 16, "Content-Encoding: aes128gcm\x00", $salt);
  $nonce   = hash_hkdf('sha256', $ikm, 12, "Content-Encoding: nonce\x00", $salt);
  $ct = openssl_encrypt($payload . "\x02", 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $nonce, $tag, '', 16);
  if ($ct === false) return null;
  return $salt . pack('N', 4096) . chr(strlen($asPub)) . $asPub . $ct . $tag;
}
/* يبني الطلب (بلا ما يصيفطو): [url, headers, body] أو null */
function crm_push_build($sub, $payload, $asKey = null) {
  $auth = crm_push_vapid_auth($sub['endpoint']);
  if ($auth === null) return null;
  if ($asKey === null) $asKey = @openssl_pkey_new(array('curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC));
  if (!$asKey) return null;
  $body = crm_push_encrypt(json_encode($payload, JSON_UNESCAPED_UNICODE), crm_push_b64d($sub['p256dh']), crm_push_b64d($sub['auth']), $asKey);
  if ($body === null) return null;
  return array($sub['endpoint'], array(
    'Content-Type: application/octet-stream',
    'Content-Encoding: aes128gcm',
    'TTL: 3600',
    'Urgency: high',
    'Authorization: ' . $auth,
  ), $body);
}
/* يصيفط فعلياً. كيرجع كود HTTP (201 = واصل) ولا 0 إلا فشل */
function crm_push_post($req) {
  $ch = curl_init($req[0]);
  curl_setopt_array($ch, array(
    CURLOPT_POST => true, CURLOPT_POSTFIELDS => $req[2], CURLOPT_HTTPHEADER => $req[1],
    CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8,
  ));
  curl_exec($ch);
  $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  return $code;
}
/* خدمات Push المعروفة فقط (باش السيرفر ما يصيفطش لأي عنوان) */
function crm_push_endpoint_ok($ep) {
  if (strpos($ep, 'https://') !== 0 || strlen($ep) > 2000) return false;
  $host = (string)parse_url($ep, PHP_URL_HOST);
  foreach (array('googleapis.com', 'mozilla.com', 'push.apple.com', 'windows.com') as $ok) {
    if ($host === $ok || substr($host, -strlen('.' . $ok)) === '.' . $ok) return true;
  }
  return false;
}
/* يصيفط لكل هواتف البنت. كيحيد الهواتف لي ما بقاوش مسجلين (404/410) */
function crm_push_to_agent($agent, $payload) {
  global $PUSH_SUBS_FILE;
  $subs = crm_push_read($PUSH_SUBS_FILE);
  $sent = 0; $removed = false; $keep = array();
  foreach ($subs as $s) {
    if (!is_array($s) || !isset($s['agent'], $s['endpoint']) || strcasecmp($s['agent'], $agent) !== 0) { $keep[] = $s; continue; }
    $req = crm_push_build($s, $payload);
    $code = $req ? crm_push_post($req) : 0;
    if ($code === 404 || $code === 410) { $removed = true; continue; }
    if ($code >= 200 && $code < 300) $sent++;
    else crm_audit('push-fail | ' . $agent . ' | code=' . $code);
    $keep[] = $s;
  }
  if ($removed) crm_push_write($PUSH_SUBS_FILE, $keep);
  return $sent;
}
/* بعد الصيفط من الشيت: إشعار وحدة لكل بنت (بلا ما نصيفطو إشعار لكل طلبية) */
function crm_push_batch($byAgent) {
  foreach ($byAgent as $agent => $list) {
    $n = count($list);
    if ($n === 0) continue;
    $lines = array();
    foreach (array_slice($list, 0, 3) as $o) {
      $lines[] = trim($o['nom'] . ' · ' . $o['produit'] . ' · ' . $o['ville'], ' ·');
    }
    if ($n > 3) $lines[] = '+ ' . ($n - 3) . ' أخرى';
    crm_push_to_agent($agent, array(
      'title' => $n === 1 ? '📥 طلبية جديدة ليك' : '📥 عندك ' . $n . ' طلبيات جداد',
      'body'  => implode("\n", $lines),
      'url'   => './',
      'tag'   => 'pv-orders',
    ));
  }
}
function crm_push_subscribe($b) {
  global $PUSH_SUBS_FILE;
  $agent = trim((string)($b['agent'] ?? ''));
  $sub   = $b['sub'] ?? null;
  if ($agent === '' || !is_array($sub) || !is_array($sub['keys'] ?? null)) crm_out(array('ok'=>false, 'err'=>'bad-sub'), 400);
  $ep   = (string)($sub['endpoint'] ?? '');
  $p256 = (string)($sub['keys']['p256dh'] ?? '');
  $auth = (string)($sub['keys']['auth'] ?? '');
  if (!crm_push_endpoint_ok($ep) || strlen(crm_push_b64d($p256)) !== 65 || strlen(crm_push_b64d($auth)) !== 16)
    crm_out(array('ok'=>false, 'err'=>'bad-sub'), 400);
  $subs = array();
  foreach (crm_push_read($PUSH_SUBS_FILE) as $s) {
    if (is_array($s) && isset($s['endpoint']) && $s['endpoint'] !== $ep) $subs[] = $s;   // نفس الهاتف = تسجيل جديد
  }
  $subs[] = array('agent' => $agent, 'endpoint' => $ep, 'p256dh' => $p256, 'auth' => $auth, 't' => time());
  if (!crm_push_write($PUSH_SUBS_FILE, $subs)) crm_out(array('ok'=>false, 'err'=>'write-failed'), 500);
  crm_out(array('ok'=>true, 'agent'=>$agent));
}
function crm_push_test($b) {
  $agent = trim((string)($b['agent'] ?? ''));
  if ($agent === '') crm_out(array('ok'=>false, 'err'=>'bad-agent'), 400);
  $n = crm_push_to_agent($agent, array(
    'title' => '🔔 تجربة الإشعارات',
    'body'  => 'إلا وصلك هاد الإشعار، كل شي خدام مزيان.',
    'url'   => './', 'tag' => 'pv-test',
  ));
  crm_out(array('ok'=>true, 'sent'=>$n));
}

/* ================================================================
 * v3.97 — الشيت → CRM (Storeep / Google Sheet → الطلبيات)
 *   POST api.php {action:'sheet_orders', rows:[{dateCreation, nom, telephone, ...}]}
 *   كيزيد غير الطلبيات الجداد. التكرار كيتحسب سيرفر-سايد بـ:
 *     التاريخ + الهاتف (آخر 9 أرقام) + المنتوج   (إلا ما كاينش هاتف → الاسم)
 *   فالتالي إلا تصيفطات نفس السطر مرتين، ما كيتزادش مرتين.
 *   كيرجع: {ok, added, dup, skip, t, results:[{i, st:'added'|'dup'|'skip', id?, why?}]}
 * ================================================================ */
/* v3.99: إشعار أوتوماتيك لكل طلبية جديدة باسم بنت (من الشيت ولا زيدتيها بيدك)
 *   أو ملي تبدل لها الطلبية للاسم ديالها. كيحسب غير التغييرات الطرية (دقيقتين)،
 *   وكيوقف إلا كانو بزاف (حماية من الاستيراد/الاسترجاع). */
function crm_push_collect_changes($old, $new, $nowms) {
  $oldBy = array();
  if (is_array($old)) { foreach ($old as $o) { if (is_array($o) && isset($o['id'])) $oldBy[(string)$o['id']] = $o; } }
  $by = array(); $n = 0;
  foreach ($new as $o) {
    if (!is_array($o) || !empty($o['_del']) || !isset($o['id'])) continue;
    $ag = trim((string)(isset($o['agent']) ? $o['agent'] : ''));
    if ($ag === '') continue;
    $prev = isset($oldBy[(string)$o['id']]) ? $oldBy[(string)$o['id']] : null;
    if ($prev !== null && trim((string)(isset($prev['agent']) ? $prev['agent'] : '')) === $ag) continue;
    $when = (float)(isset($o['_u']) ? $o['_u'] : 0);
    if (isset($o['_f']['agent'])) $when = max($when, (float)$o['_f']['agent']);
    if ($when < $nowms - 120000) continue;
    $by[$ag][] = array(
      'nom'    => (string)(isset($o['nom']) ? $o['nom'] : ''),
      'produit'=> (string)(isset($o['produit']) ? $o['produit'] : ''),
      'ville'  => (string)(isset($o['ville']) ? $o['ville'] : ''),
    );
    $n++;
  }
  return ($n > 30) ? array() : $by;
}
function crm_sheet_text($v) {
  if ($v === null || is_array($v) || is_object($v)) return '';
  return trim((string)$v);
}
function crm_sheet_num($v, $def) {
  if ($v === null || is_array($v) || is_object($v)) return $def;
  $s = str_replace(',', '.', trim((string)$v));
  if ($s === '' || !is_numeric($s)) return $def;
  $f = (float)$s;
  return ($f == floor($f)) ? (int)$f : $f;
}
/* صيغ مقبولة: YYYY-MM-DD (وبالساعة) ولا DD/MM/YYYY (ولا DD-MM-YYYY) */
function crm_sheet_date($v) {
  $s = crm_sheet_text($v);
  if ($s === '') return '';
  if (preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})/', $s, $m)) { $y = (int)$m[1]; $mo = (int)$m[2]; $d = (int)$m[3]; }
  elseif (preg_match('/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})/', $s, $m)) { $d = (int)$m[1]; $mo = (int)$m[2]; $y = (int)$m[3]; }
  else return null;   // ماشي تاريخ صحيح
  return checkdate($mo, $d, $y) ? sprintf('%04d-%02d-%02d', $y, $mo, $d) : null;
}
/* الهاتف: غير الأرقام، +212 / 212 → 0، ورقم 9 أرقام بلا 0 → كنزيدو 0 */
function crm_sheet_phone($v) {
  $d = preg_replace('/\D+/', '', crm_sheet_text($v));
  if (strlen($d) === 12 && strpos($d, '212') === 0) $d = '0' . substr($d, 3);
  elseif (strlen($d) === 9 && $d[0] !== '0') $d = '0' . $d;
  return $d;
}
function crm_sheet_key($date, $phone, $nom, $produit) {
  $p = crm_sheet_phone($phone);
  $p9 = strlen($p) >= 9 ? substr($p, -9) : '';
  $who = $p9 !== '' ? 'p:' . $p9
                    : 'n:' . strtolower(preg_replace('/\s+/u', ' ', crm_sheet_text($nom)));
  return $date . '|' . $who . '|' . strtolower(preg_replace('/\s+/u', ' ', crm_sheet_text($produit)));
}
/* كينقّي سطر الشيت ويحوّلو لطلبية CRM. كيرجع [سبب الرفض|null, الطلبية|null] */
function crm_sheet_norm($r) {
  $raw = isset($r['dateCreation']) ? $r['dateCreation'] : '';
  $dc = crm_sheet_date($raw);
  if ($dc === null || $dc === '') return array(crm_sheet_text($raw) === '' ? 'no-date' : 'bad-date', null);
  $tel = crm_sheet_phone(isset($r['telephone']) ? $r['telephone'] : '');
  $nom = crm_sheet_text(isset($r['nom']) ? $r['nom'] : '');
  if ($tel === '' && $nom === '') return array('no-name-or-phone', null);

  $o = array();
  $o['dateCreation'] = $dc;
  $dco = crm_sheet_date(isset($r['dateConfirmation']) ? $r['dateConfirmation'] : '');
  $o['dateConfirmation'] = ($dco === null || $dco === '') ? $dc : $dco;
  foreach (array('dateExp', 'dateLiv') as $f) {
    $x = crm_sheet_date(isset($r[$f]) ? $r[$f] : '');
    $o[$f] = ($x === null) ? '' : $x;
  }
  $o['telephone'] = $tel;
  $o['nom'] = $nom;
  foreach (array('idCmd','ville','adresse','produit','statut','livraison','remarques','agent','link',
                 'carousell','carosellFlag','originLead','livreur','tracking','motif','fees') as $f) {
    $o[$f] = crm_sheet_text(isset($r[$f]) ? $r[$f] : '');
  }
  $o['qte']        = max(1, (int)crm_sheet_num(isset($r['qte']) ? $r['qte'] : '', 1));
  $o['prix']       = crm_sheet_num(isset($r['prix']) ? $r['prix'] : '', 0);
  $o['upsell']     = crm_sheet_num(isset($r['upsell']) ? $r['upsell'] : '', 0);
  $o['commission'] = crm_sheet_num(isset($r['commission']) ? $r['commission'] : '', 0);
  return array(null, $o);
}
/* v3.100: عداد الدور ديال الشيت (Meryam → AYA → imane → safa) محفوظ فملف وحدو.
 * قبل كان محسوب من عدد الطلبيات — ولا تبدلات الدمج/الحذف كانو كيرجعوه لصفر
 * → كل الطلبيات كيمشيو لمريم. دابا كل طلبية جديدة من الشيت كتزيد +1 ف الملف. */
function crm_rr_get() {
  global $DATA_DIR;
  $s = @file_get_contents($DATA_DIR . '/sheet_rr.json');
  $j = json_decode((string)$s, true);
  return (is_array($j) && isset($j['n'])) ? (int)$j['n'] : null;
}
function crm_rr_set($n) {
  global $DATA_DIR;
  @file_put_contents($DATA_DIR . '/sheet_rr.json', json_encode(array('n' => (int)$n)));
}
/* لائحة البنات اللي كيتقسمو عليهم طلبيات الشيت.
 * كتقرا من sheet_agents.json (فنفس مجلد crm_data.json) — بلا ما تبدل الكود.
 * مثال الملف: ["Meryam","AYA","safa"]   (الأسماء بالضبط كيفما فـCRM)
 * إلا ما كانش الملف ولا خاوي → الافتراضي Meryam, AYA, safa */
function crm_sheet_agents() {
  global $DATA_DIR;
  $def = array('Meryam', 'AYA', 'safa');
  $s = @file_get_contents($DATA_DIR . '/sheet_agents.json');
  $j = json_decode((string)$s, true);
  if (!is_array($j)) return $def;
  $out = array();
  foreach ($j as $a) {
    $a = trim((string)$a);
    if ($a !== '' && !in_array($a, $out, true)) $out[] = $a;
  }
  return count($out) ? $out : $def;
}
function crm_sheet_orders($b) {
  global $LOCK_FILE;
  $rows = (isset($b['rows']) && is_array($b['rows'])) ? array_values($b['rows']) : null;
  if ($rows === null) crm_out(array('ok'=>false, 'err'=>'bad-rows'), 400);
  if (count($rows) > 2000) crm_out(array('ok'=>false, 'err'=>'too-many-rows', 'max'=>2000), 413);

  $fh = @fopen($LOCK_FILE, 'c');
  if ($fh) @flock($fh, LOCK_EX);

  $data = crm_read_raw(true);
  $cur = isset($data['paraveda_orders_v5']['d']) ? crm_unwrap($data['paraveda_orders_v5']['d']) : array();
  if (!is_array($cur)) $cur = array();
  $cur = array_values($cur);
  $prevT = isset($data['paraveda_orders_v5']['t']) ? (int)$data['paraveda_orders_v5']['t'] : 0;

  /* مفاتيح الطلبيات الموجودة (الحية) + أكبر id (حتى الممسوحة) باش ما نعاودوش نستعملو id */
  $keys = array(); $maxId = 0;
  /* v3.98: توزيع الطلبيات على البنات بالدور (round-robin).
   * $rr = عدد الطلبيات لي جاو من الشيت (حتى الممسوحين)، كيتزاد كل طلبية جديدة. */
  $agents = crm_sheet_agents();   // لائحة البنات ديال الشيت (ملف sheet_agents.json)
  $rr = 0;
  foreach ($cur as $o) {
    if (!is_array($o)) continue;
    if (isset($o['id']) && is_numeric($o['id']) && (int)$o['id'] > $maxId) $maxId = (int)$o['id'];
    if (isset($o['src']) && $o['src'] === 'sheet') $rr++;
    $keys[crm_sheet_key(
      isset($o['dateCreation']) ? (string)$o['dateCreation'] : '',
      isset($o['telephone'])    ? $o['telephone'] : '',
      isset($o['nom'])          ? $o['nom'] : '',
      isset($o['produit'])      ? $o['produit'] : ''
    )] = true;
  }

  $rrS = crm_rr_get();              // v3.100: العداد المحفوظ هو المرجع
  $rr = ($rrS !== null) ? $rrS : 0;   // أول مرة: تبدا من مريم
  $nowms  = (int)(microtime(true) * 1000);
  $nextId = max((int)(microtime(true) * 1000000), $maxId + 1);
  $out = array(); $added = 0; $dup = 0; $skip = 0;
  $addedBy = array();   // v3.98: الطلبيات الجداد لكل بنت (للإشعارات)
  foreach ($rows as $i => $r) {
    if (!is_array($r)) { $out[] = array('i'=>$i, 'st'=>'skip', 'why'=>'bad-row'); $skip++; continue; }
    list($why, $o) = crm_sheet_norm($r);
    if ($why !== null) { $out[] = array('i'=>$i, 'st'=>'skip', 'why'=>$why); $skip++; continue; }
    $k = crm_sheet_key($o['dateCreation'], $o['telephone'], $o['nom'], $o['produit']);
    if (isset($keys[$k])) { $out[] = array('i'=>$i, 'st'=>'dup'); $dup++; continue; }

    $o['agent'] = $agents[$rr % count($agents)];   // الدور: Meryam → AYA → safa
    $o['idCmd'] = '1';                              // v3.98: ID ديما default = 1
    $o['src']   = 'sheet';
    $o['originLead'] = 'Facebook';                 // كل طلبيات الشيت جاية من Facebook
    $rr++;
    $o['id'] = $nextId++;
    $o['_u'] = $nowms;
    $f = array();
    foreach ($o as $fk => $fv) { if ($fk !== 'id' && $fk !== '_u') $f[$fk] = $nowms; }
    $o['_f'] = $f;

    $cur[] = $o;
    $keys[$k] = true;
    $out[] = array('i'=>$i, 'st'=>'added', 'id'=>$o['id'], 'agent'=>$o['agent']);
    $added++;
    $addedBy[$o['agent']][] = array('nom'=>$o['nom'], 'produit'=>$o['produit'], 'ville'=>$o['ville']);
  }

  if ($added === 0) {
    if ($fh) { @flock($fh, LOCK_UN); @fclose($fh); }
    if ($skip > 0) crm_audit("sheet-orders | added=0 | dup=$dup | skip=$skip");
    crm_out(array('ok'=>true, 'added'=>0, 'dup'=>$dup, 'skip'=>$skip, 'results'=>$out));
  }

  crm_backup();
  $t = max($prevT + 1, $nowms);
  $data['paraveda_orders_v5'] = array('t' => $t, 'd' => $cur);
  $ok = crm_write_all($data);
  if ($ok) crm_journal_append('paraveda_orders_v5', $t, $cur);
  if ($fh) { @flock($fh, LOCK_UN); @fclose($fh); }

  if (!$ok) crm_out(array('ok'=>false, 'err'=>'write-failed'), 500);
  crm_rr_set($rr);                  // v3.100
  crm_audit("sheet-orders | added=$added | dup=$dup | skip=$skip | t=$t");
  try { crm_push_batch($addedBy); } catch (Throwable $__e) { crm_audit('push-error | ' . $__e->getMessage()); }   // v3.98: ما كيوقفش الصيفط
  crm_out(array('ok'=>true, 'added'=>$added, 'dup'=>$dup, 'skip'=>$skip, 't'=>$t, 'results'=>$out));
}

/* ================================================================
 * v3.100 — طلبية سريعة من البنت (من صفحة quick.html)
 *   POST api.php {action:'quick_order', agent:'imane', order:{nom, telephone, ville, adresse, produit, qte, prix, dateCreation?}}
 *   الطلبية كتتسجل باسم البنت لي داخلة بحسابها (ما كتدخلش فالدور ديال الشيت).
 *   كتصيفط إشعار لهاد البنت أوتوماتيك. التكرار: نفس التاريخ + الهاتف + المنتوج → 409.
 *   كيرجع: {ok, id, agent} | {ok:false, err}
 * ================================================================ */
function crm_quick_order($b) {
  global $LOCK_FILE;
  $agents = array('Meryam', 'AYA', 'imane', 'safa');
  $ag = isset($b['agent']) ? trim((string)$b['agent']) : '';
  if (!in_array($ag, $agents, true)) crm_out(array('ok'=>false, 'err'=>'bad-agent'), 400);
  $r = (isset($b['order']) && is_array($b['order'])) ? $b['order'] : null;
  if ($r === null) crm_out(array('ok'=>false, 'err'=>'bad-order'), 400);
  foreach (array('nom', 'telephone', 'ville', 'adresse', 'produit', 'qte', 'prix') as $f) {
    if (!isset($r[$f]) || trim((string)$r[$f]) === '') crm_out(array('ok'=>false, 'err'=>'missing-' . $f), 400);
  }
  if (!isset($r['dateCreation']) || trim((string)$r['dateCreation']) === '') $r['dateCreation'] = date('Y-m-d');
  list($why, $o) = crm_sheet_norm($r);
  if ($why !== null) crm_out(array('ok'=>false, 'err'=>$why), 400);
  if ($o['telephone'] === '') crm_out(array('ok'=>false, 'err'=>'missing-telephone'), 400);

  $fh = @fopen($LOCK_FILE, 'c');
  if ($fh) @flock($fh, LOCK_EX);
  $data = crm_read_raw(true);
  $cur = isset($data['paraveda_orders_v5']['d']) ? crm_unwrap($data['paraveda_orders_v5']['d']) : array();
  if (!is_array($cur)) $cur = array();
  $cur = array_values($cur);
  $prevT = isset($data['paraveda_orders_v5']['t']) ? (int)$data['paraveda_orders_v5']['t'] : 0;

  $keyNew = crm_sheet_key($o['dateCreation'], $o['telephone'], $o['nom'], $o['produit']);
  $maxId = 0;
  foreach ($cur as $x) {
    if (!is_array($x)) continue;
    if (isset($x['id']) && is_numeric($x['id']) && (int)$x['id'] > $maxId) $maxId = (int)$x['id'];
    if (!empty($x['_del'])) continue;
    $k = crm_sheet_key(
      isset($x['dateCreation']) ? (string)$x['dateCreation'] : '',
      isset($x['telephone'])    ? $x['telephone'] : '',
      isset($x['nom'])          ? $x['nom'] : '',
      isset($x['produit'])      ? $x['produit'] : ''
    );
    if ($k === $keyNew) {
      if ($fh) { @flock($fh, LOCK_UN); @fclose($fh); }
      crm_out(array('ok'=>false, 'err'=>'dup'), 409);
    }
  }

  $nowms = (int)(microtime(true) * 1000);
  $o['agent'] = $ag;
  $o['idCmd'] = '1';
  $o['src']   = 'manual';
  $o['id']    = max((int)(microtime(true) * 1000000), $maxId + 1);
  $o['_u']    = $nowms;
  $f = array();
  foreach ($o as $fk => $fv) { if ($fk !== 'id' && $fk !== '_u') $f[$fk] = $nowms; }
  $o['_f'] = $f;
  $cur[] = $o;

  crm_backup();
  $t = max($prevT + 1, $nowms);
  $data['paraveda_orders_v5'] = array('t' => $t, 'd' => $cur);
  $ok = crm_write_all($data);
  if ($ok) crm_journal_append('paraveda_orders_v5', $t, $cur);
  if ($fh) { @flock($fh, LOCK_UN); @fclose($fh); }
  if (!$ok) crm_out(array('ok'=>false, 'err'=>'write-failed'), 500);
  crm_audit("quick-order | agent=$ag | id=" . $o['id'] . " | t=$t");
  try {
    crm_push_batch(array($ag => array(array('nom'=>$o['nom'], 'produit'=>$o['produit'], 'ville'=>$o['ville']))));
  } catch (Throwable $__e) { crm_audit('push-error | ' . $__e->getMessage()); }
  crm_out(array('ok'=>true, 'id'=>$o['id'], 'agent'=>$ag, 't'=>$t));
}

/* ================================================================
 * v3.101 — Digylog: إرسال الطلبيات المؤكدة (Confirmé) أوتوماتيك
 *   كل بنت ليها متجر خاص فـDigylog (store). الطلبية كتمشي لمتجر البنت لي عندها.
 *   الإعدادات فملف digylog_cfg.json (التوكن ما كيتعرضش). كيتشغل بـcron:
 *     GET api.php?action=digylog_sync&token=...   (كل دقيقة)
 *   الطلبية كتتصيفط مرة وحدة: كتتعلم dlSent. إلا فشل، كتعاود (حتى 5 مرات).
 *   غير الطلبيات لي تأكدات (statut = Confirmé) بعد التفعيل (_f.statut >= since).
 * ================================================================ */
function crm_dl_base() { return 'https://api.digylog.com/api/v2/seller'; }
function crm_dl_agents() { return array('Meryam', 'AYA', 'imane', 'safa'); }
function crm_dl_cfg_get() {
  global $DATA_DIR;
  $s = @file_get_contents($DATA_DIR . '/digylog_cfg.json');
  $j = json_decode((string)$s, true);
  return is_array($j) ? $j : array();
}
function crm_dl_cfg_set($c) {
  global $DATA_DIR;
  @file_put_contents($DATA_DIR . '/digylog_cfg.json', json_encode($c, JSON_UNESCAPED_UNICODE));
}
function crm_dl_http($method, $path, $token, $body = null) {
  if (!function_exists('curl_init')) return array(0, '', 'no-curl');
  $ch = curl_init(crm_dl_base() . $path);
  $h = array('Accept: application/json', 'Referer: https://apiseller.digylog.com', 'Authorization: Bearer ' . $token);
  if ($body !== null) $h[] = 'Content-Type: application/json';
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $h);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
  curl_setopt($ch, CURLOPT_TIMEOUT, 25);
  if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body, JSON_UNESCAPED_UNICODE));
  $resp = curl_exec($ch);
  $err  = (string)curl_error($ch);
  $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  return array($code, $resp === false ? '' : (string)$resp, $err);
}
/* كنقبلو Copy value أو السطر الكامل "Authorization: Bearer …" باش ما
 * يتبعثش بالغلط Bearer Authorization: Bearer ويعطينا 401. */
function crm_dl_bearer_value($raw) {
  $v = trim((string)$raw, " \t\r\n\"'");
  $v = preg_replace('/^authorization\s*:\s*/i', '', $v);
  $v = preg_replace('/^bearer\s+/i', '', trim($v));
  return trim($v, " \t\r\n\"'");
}
/* API الداخلي اللي كيستعمل seller.digylog.com للبحث بالهاتف. مختلف على
 * public /api/v2/seller، وكيحتاج Seller session bearer مؤقت. */
function crm_dl_internal_http($path, $token) {
  if (!function_exists('curl_init')) return array(0, '', 'no-curl');
  $token = crm_dl_bearer_value($token);
  $ch = curl_init('https://api.digylog.com/api/seller/v48' . $path);
  curl_setopt_array($ch, array(
    CURLOPT_HTTPHEADER => array('Accept: application/json, text/plain, */*', 'Referer: https://seller.digylog.com/', 'Origin: https://seller.digylog.com', 'Authorization: Bearer ' . $token),
    CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_TIMEOUT => 25
  ));
  $resp = curl_exec($ch); $err = (string)curl_error($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
  return array($code, $resp === false ? '' : (string)$resp, $err);
}
function crm_dl_order_row($o) {
  return array(
    'num'         => (string)$o['id'],
    'name'        => trim((string)$o['nom']),
    'phone'       => trim((string)$o['telephone']),
    'address'     => trim((string)$o['adresse']),
    'city'        => trim((string)$o['ville']),
    'price'       => (float)$o['prix'],
    'openproduct' => 1,
    'cantry'      => 0,
    'note'        => '',
    'refs'        => array(array('ref' => '', 'designation' => trim((string)$o['produit']), 'quantity' => max(1, (int)$o['qte'])))
  );
}
function crm_dl_body($store, $network, $sentType, $rows) {
  return array(
    'network'        => (int)$network,
    'store'          => (string)$store,
    'sentType'       => (int)$sentType,
    'checkDuplicate' => 1,
    'orders'         => $rows
  );
}
/* Digylog كيرجع num/traking جداد من بعد إنشاء الطلبية. كنستخرجو السطور
 * من أي غلاف (data/orders/results...) ونربطوهم بنفس ترتيب batch المرسل. */
function crm_dl_response_records($v, &$out) {
  if (!is_array($v)) return;
  $assoc = array_keys($v) !== range(0, count($v) - 1);
  if ($assoc) {
    $hasRef = false;
    foreach (array('num','orderNum','order_num','idOrder','orderId','order_id','traking','tracking','trackingId') as $k) {
      if (isset($v[$k]) && !is_array($v[$k]) && trim((string)$v[$k]) !== '') { $hasRef = true; break; }
    }
    if ($hasRef) $out[] = $v;
  }
  foreach ($v as $child) if (is_array($child)) crm_dl_response_records($child, $out);
}
function crm_dl_response_value($a, $keys) {
  if (!is_array($a)) return '';
  foreach ($keys as $k) if (isset($a[$k]) && !is_array($a[$k]) && trim((string)$a[$k]) !== '') return trim((string)$a[$k]);
  return '';
}
/* admin: POST {action:'digylog_admin', op:'get'|'save'|'test'|'dry'} + header X-Sync-Token */
function crm_dl_admin($b) {
  global $SECRET, $AUDIT_FILE;
  if (!hash_equals($SECRET, crm_token())) crm_out(array('ok'=>false, 'err'=>'token'), 403);
  $op = isset($b['op']) ? (string)$b['op'] : 'get';
  $c = crm_dl_cfg_get();
  $t = isset($c['token']) ? (string)$c['token'] : '';
  $stores = array();
  foreach (crm_dl_agents() as $ag) $stores[$ag] = (isset($c['stores'][$ag]) ? (string)$c['stores'][$ag] : '');

  if ($op === 'get') {
    crm_out(array('ok'=>true, 'cfg'=>array(
      'enabled'   => !empty($c['enabled']) ? 1 : 0,
      'network'   => isset($c['network']) ? (int)$c['network'] : 1,
      'sentType'  => isset($c['sentType']) ? (int)$c['sentType'] : 0,
      'stores'    => $stores,
      'since'     => isset($c['since']) ? (int)$c['since'] : 0,
      'hasToken'  => $t !== '',
      'tokenTail' => $t !== '' ? substr($t, -4) : '',
      'hasSellerToken' => !empty($c['sellerToken']),
      'sellerTokenTail' => !empty($c['sellerToken']) ? substr((string)$c['sellerToken'], -4) : ''
    )));
  }
  if ($op === 'clear_seller_token') {
    unset($c['sellerToken']); crm_dl_cfg_set($c); crm_out(array('ok'=>true));
  }
  if ($op === 'save') {
    if (isset($b['token']) && trim((string)$b['token']) !== '') $c['token'] = trim((string)$b['token']);
    if (isset($b['sellerToken']) && trim((string)$b['sellerToken']) !== '') {
      $c['sellerToken'] = crm_dl_bearer_value($b['sellerToken']);
    }
    if (!empty($b['clearSellerToken'])) unset($c['sellerToken']);
    if (isset($b['network'])) $c['network'] = (int)$b['network'];
    if (isset($b['sentType'])) {
      $st = (int)$b['sentType'];
      if (!in_array($st, array(0, 1, 2), true)) crm_out(array('ok'=>false, 'err'=>'bad-sentType'), 400);
      $c['sentType'] = $st;
    }
    if (isset($b['stores']) && is_array($b['stores'])) {
      $s = array();
      foreach (crm_dl_agents() as $ag) $s[$ag] = isset($b['stores'][$ag]) ? trim((string)$b['stores'][$ag]) : '';
      $c['stores'] = $s;
    }
    $en = !empty($b['enabled']) ? 1 : 0;
    if ($en && empty($c['enabled'])) $c['since'] = (int)(microtime(true) * 1000);   // أول تفعيل: غير الطلبيات الجداد
    $c['enabled'] = $en;
    crm_dl_cfg_set($c);
    crm_audit('digylog-save | enabled=' . $en . ' | sentType=' . (isset($c['sentType']) ? $c['sentType'] : 0));
    crm_out(array('ok'=>true));
  }
  if ($op === 'test') {
    if ($t === '') crm_out(array('ok'=>false, 'err'=>'no-token'), 400);
    $out = array();
    foreach (array('/networks', '/stores') as $p) {
      list($code, $body, $err) = crm_dl_http('GET', $p, $t);
      $out[$p] = array('code'=>$code, 'body'=>substr($body, 0, 1500), 'err'=>$err);
    }
    /* PUT /webhook/test: Digylog يصيفط حدث تجريبي لـwebhook المسجل (num=55 ما كاينش فـCRM، كيتجاهل).
     * إلا 400 "webhook not configured" = ما كاينش webhook مسجل. */
    list($tc, $tb, $te) = crm_dl_http('PUT', '/webhook/test', $t, array('eventType' => 'order-status-changed'));
    $out['/webhook/test'] = array('code'=>$tc, 'body'=>substr($tb, 0, 1500), 'err'=>$te);
    /* تشخيص: السيرفر كيجرب الـwebhook نفسو (نفس الرابط اللي مسجل فـDigylog) وكيعرض الجواب */
    $selfBody = json_encode(array('eventType'=>'order-status-changed', 'payload'=>array('num'=>'55', 'idStatus'=>'6', 'status'=>'Livrée')));
    $ch = curl_init('https://paraveda.store/api.php?action=digylog_hook&token=' . urlencode($SECRET));
    curl_setopt_array($ch, array(CURLOPT_POST=>true, CURLOPT_POSTFIELDS=>$selfBody, CURLOPT_HTTPHEADER=>array('Content-Type: application/json'), CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>15));
    $sb = curl_exec($ch); $sc = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $se = (string)curl_error($ch); curl_close($ch);
    $out['/self-hook'] = array('code'=>$sc, 'body'=>substr((string)$sb, 0, 800), 'err'=>$se);
    /* تشخيص: آخر سطور الـwebhook من audit.log (شكل الطلب الحقيقي اللي وصل من Digylog) */
    $__al = (is_file($AUDIT_FILE)) ? array_slice(array_values(array_filter(explode("\n", (string)@file_get_contents($AUDIT_FILE)))), -500) : array();
    $__hk = array_values(array_filter($__al, function ($l) { return strpos($l, 'digylog-hook') !== false; }));
    $out['/hook-log'] = array('lines' => array_slice($__hk, -10));
    /* عاود عالج تلقائياً webhooks ديال Livrée/Retournée اللي فاتو قبل إصلاح lookup. */
    $out['/reconcile'] = crm_dl_reconcile_recent();
    crm_out(array('ok'=>true, 'test'=>$out));
  }
  if ($op === 'known_trackings') {
    /* كنبدأو بالمخزن محلياً، ومن بعد كنجربو listing ديال Digylog مباشرة
       باش نجيبو حتى طلبيات اليوم/البارح/الشهور اللي ما وصلش webhook ديالها. */
    $local = crm_dl_known_trackings(false);
    $remote = crm_dl_remote_trackings();
    $allMap = array();
    foreach ($local as $tr) $allMap[$tr] = true;
    if (!empty($remote['trackings']) && is_array($remote['trackings'])) foreach ($remote['trackings'] as $tr) $allMap[$tr] = true;
    $all = array_keys($allMap);
    crm_out(array('ok'=>true, 'trackings'=>$all, 'total'=>count($all), 'local'=>count($local),
      'remote'=>isset($remote['count']) ? (int)$remote['count'] : 0,
      'remoteEndpoint'=>isset($remote['endpoint']) ? $remote['endpoint'] : '',
      'remoteTests'=>isset($remote['tests']) ? $remote['tests'] : array()));
  }
  if ($op === 'reconcile') {
    $raw = isset($b['trackings']) ? $b['trackings'] : array();
    if (is_string($raw)) $raw = preg_split('/[\s,;]+/', $raw, -1, PREG_SPLIT_NO_EMPTY);
    if (!is_array($raw) || count($raw) === 0) crm_out(array('ok'=>false, 'err'=>'no-trackings'), 400);
    crm_out(crm_dl_reconcile_recent($raw));
  }
  if ($op === 'repair_untracked') {
    $limit = isset($b['limit']) ? (int)$b['limit'] : 100;
    crm_out(crm_dl_repair_untracked(max(1, min(100, $limit))));
  }
  if ($op === 'phone_candidates') {
    crm_out(crm_dl_phone_candidates());
  }
  if ($op === 'match_phones') {
    $ids = isset($b['ids']) && is_array($b['ids']) ? $b['ids'] : array();
    $temporarySellerToken = isset($b['sellerToken']) ? (string)$b['sellerToken'] : '';
    crm_out(crm_dl_match_phones($ids, $temporarySellerToken));
  }
  if ($op === 'dry') crm_out(crm_dl_run(true));
  crm_out(array('ok'=>false, 'err'=>'bad-op'), 400);
}
/* يشتغل: من cron (GET) أو من admin (dry) */
function crm_dl_run($dry = false) {
  global $LOCK_FILE, $DATA_DIR;
  $c = crm_dl_cfg_get();
  if (!$dry && empty($c['enabled'])) return array('ok'=>true, 'skipped'=>'disabled');
  $since   = isset($c['since']) ? (int)$c['since'] : 0;
  $token   = isset($c['token']) ? (string)$c['token'] : '';
  $network = isset($c['network']) ? (int)$c['network'] : 1;
  $sentTyp = isset($c['sentType']) ? (int)$c['sentType'] : 0;
  $stores  = array();
  foreach (crm_dl_agents() as $ag) $stores[$ag] = isset($c['stores'][$ag]) ? trim((string)$c['stores'][$ag]) : '';
  if (!$dry && $token === '') return array('ok'=>false, 'err'=>'no-token');
  if ($since <= 0 && !$dry) return array('ok'=>false, 'err'=>'not-enabled-properly');

  $runLock = @fopen($DATA_DIR . '/.dl.lock', 'c');
  if ($runLock && !$dry && !@flock($runLock, LOCK_EX | LOCK_NB)) return array('ok'=>true, 'skipped'=>'busy');

  /* 1) قراية (لوك قصير) + اختيار الطلبيات */
  $fh = @fopen($LOCK_FILE, 'c'); if ($fh) @flock($fh, LOCK_EX);
  $data = crm_read_raw(true);
  $cur = isset($data['paraveda_orders_v5']['d']) ? crm_unwrap($data['paraveda_orders_v5']['d']) : array();
  if (!is_array($cur)) $cur = array();
  $prevT = isset($data['paraveda_orders_v5']['t']) ? (int)$data['paraveda_orders_v5']['t'] : 0;
  if ($fh) { @flock($fh, LOCK_UN); @fclose($fh); }

  $groups = array(); $skipped = array();
  foreach ($cur as $o) {
    if (!is_array($o) || !empty($o['_del']) || !empty($o['dlSent'])) continue;
    $st = isset($o['statut']) ? (string)$o['statut'] : '';
    if (stripos($st, 'confirm') === false) continue;
    if (trim((string)(isset($o['livraison']) ? $o['livraison'] : '')) !== '') continue;   // Suivie فارغ = ما تصيفطاتش بعد
    $stamp = (isset($o['_f']['statut']) && is_numeric($o['_f']['statut'])) ? (float)$o['_f']['statut'] : 0;
    if (!($since > 0 ? ($stamp >= $since) : $dry)) continue;   // بعد التفعيل: غير الجداد. قبل التفعيل: المعاينة فقط
    $tries = isset($o['dlTries']) ? (int)$o['dlTries'] : 0;
    if ($tries >= 5) continue;
    $id = (string)$o['id'];
    $ag = isset($o['agent']) ? (string)$o['agent'] : '';
    $store = isset($stores[$ag]) ? $stores[$ag] : '';
    if ($store === '') { $skipped[] = array('id'=>$id, 'why'=>'no-store-for-agent', 'agent'=>$ag); continue; }
    $miss = '';
    foreach (array('nom', 'telephone', 'adresse', 'ville', 'produit') as $f) {
      if (!isset($o[$f]) || trim((string)$o[$f]) === '') { $miss = $f; break; }
    }
    if ($miss !== '') { $skipped[] = array('id'=>$id, 'why'=>'missing-' . $miss); continue; }
    $groups[$store][] = array('id'=>$id, 'row'=>crm_dl_order_row($o));
  }

  if ($dry) {
    $sum = array();
    foreach ($groups as $store => $rows) {
      $sum[] = array('store'=>$store, 'count'=>count($rows), 'sample'=>crm_dl_body($store, $network, $sentTyp, array_slice(array_map(function ($r) { return $r['row']; }, $rows), 0, 1)));
    }
    $note = ($since > 0) ? 'هادي هي الطلبيات لي غادي تمشي للمتاجر (بعد التفعيل).' : 'مازال ما تفعلاتش الإرسال. هاد الأرقام معاينة فقط: الطلبيات القديمة ما غاديش تتصيفط. ملي تفعّل، غير الطلبيات Confirmé الجداد غادي يمشيو.';
    /* تشخيص: كل طلبية Confirmé (بلا بيانات حساسة) + علاش ما تصيفطاتش */
    $dbg = array(); $dbgN = 0;
    foreach ($cur as $o) {
      if (!is_array($o) || !empty($o['_del'])) continue;
      $st = isset($o['statut']) ? (string)$o['statut'] : '';
      if (stripos($st, 'confirm') === false) continue;
      $stp = (isset($o['_f']['statut']) && is_numeric($o['_f']['statut'])) ? (float)$o['_f']['statut'] : 0;
      $dbgN++;
      $dbg[] = array(
        'id'      => (string)(isset($o['id']) ? $o['id'] : ''),
        'nom'     => mb_substr((string)(isset($o['nom']) ? $o['nom'] : ''), 0, 20),
        'agent'   => (string)(isset($o['agent']) ? $o['agent'] : ''),
        'liv'     => (string)(isset($o['livraison']) ? $o['livraison'] : ''),
        'stampOk' => ($since > 0 ? ($stp >= $since ? 1 : 0) : -1),
        'dlSent'  => !empty($o['dlSent']) ? 1 : 0,
        'tries'   => isset($o['dlTries']) ? (int)$o['dlTries'] : 0,
        'err'     => mb_substr((string)(isset($o['dlErr']) ? $o['dlErr'] : ''), 0, 160)
      );
    }
    usort($dbg, function ($a, $b) { return ($b['stampOk'] - $a['stampOk']) ?: ($b['dlSent'] - $a['dlSent']); });
    $dbg = array_slice($dbg, 0, 40);
    return array('ok'=>true, 'dry'=>true, 'note'=>$note, 'sentType'=>$sentTyp, 'network'=>$network, 'since'=>$since, 'groups'=>$sum, 'skipped'=>$skipped, 'confirmedTotal'=>$dbgN, 'confirmedDebug'=>$dbg);
  }

  /* 2) إرسال (بلا لوك) */
  $sent = array(); $failed = array();
  foreach ($groups as $store => $rows) {
    for ($i = 0; $i < count($rows); $i += 50) {
      $chunk = array_slice($rows, $i, 50);
      $body = crm_dl_body($store, $network, $sentTyp, array_map(function ($r) { return $r['row']; }, $chunk));
      list($code, $resp, $err) = crm_dl_http('POST', '/orders/standard', $token, $body);
      $ok = ($code >= 200 && $code < 300);
      $j = json_decode($resp, true);
      if ($ok && is_array($j) && isset($j['success']) && $j['success'] === false) $ok = false;
      $responseRows = array();
      if ($ok && is_array($j)) crm_dl_response_records($j, $responseRows);
      foreach ($chunk as $__ri => $r) {
        if ($ok) {
          /* أولا نقلبو على السطر اللي فيه مرجع CRM؛ إلا جواب Digylog ما رجعش
             المرجع الأصلي، ترتيب الجواب مطابق لترتيب batch وكنستعملو index. */
          $rr = null;
          foreach ($responseRows as $candidate) {
            /* Digylog كيرجع غالباً نفس num اللي صيفطناه (CRM id). النسخة
               القديمة ما كانتش كتستعمل num فالمطابقة، وهادشي خلا batch كامل
               يتعلّم Expédier vers بلا Tracking. */
            $orig = crm_dl_response_value($candidate, array('externalReference','external_reference','clientReference','client_reference','reference','ref','sourceNum','source_num','num','orderNum','order_num'));
            if ($orig !== '' && $orig === (string)$r['id']) { $rr = $candidate; break; }
          }
          if ($rr === null && count($responseRows) === count($chunk) && isset($responseRows[$__ri])) $rr = $responseRows[$__ri];
          $rowOk = is_array($rr);
          if ($rowOk && isset($rr['isSuccess']) && ($rr['isSuccess'] === false || $rr['isSuccess'] === 0 || $rr['isSuccess'] === 'false')) $rowOk = false;
          if ($rowOk && isset($rr['success']) && ($rr['success'] === false || $rr['success'] === 0 || $rr['success'] === 'false')) $rowOk = false;
          $rowTracking = $rowOk ? crm_dl_response_value($rr, array('traking','tracking','trackingId','tracking_id','trackingNumber','tracking_number')) : '';
          /* ما نكتبوش Expédier vers إلا عندنا دليل لكل سطر: Tracking حقيقي.
             HTTP 200 ديال batch بوحدو ماشي نجاح جميع الطلبيات. */
          if (!$rowOk || $rowTracking === '') {
            $msg = is_array($rr) ? crm_dl_response_value($rr, array('message','error','errors')) : '';
            $failed[$r['id']] = 'digylog-no-tracking' . ($msg !== '' ? (': ' . $msg) : '') . ' | ' . substr($resp, 0, 120);
            continue;
          }
          $sent[$r['id']] = array(
            'raw'      => substr($resp, 0, 500),
            'num'      => crm_dl_response_value($rr, array('num','orderNum','order_num')),
            'id'       => crm_dl_response_value($rr, array('idOrder','orderId','order_id','id')),
            'tracking' => $rowTracking
          );
        } else $failed[$r['id']] = ($err !== '' ? $err : ('http-' . $code . ' ' . substr($resp, 0, 150)));
      }
    }
  }

  /* 3) كتابة النتيجة (لوك) */
  $applied = 0;
  if ($sent || $failed) {
    $fh = @fopen($LOCK_FILE, 'c'); if ($fh) @flock($fh, LOCK_EX);
    $data = crm_read_raw(true);
    $cur = isset($data['paraveda_orders_v5']['d']) ? crm_unwrap($data['paraveda_orders_v5']['d']) : array();
    if (!is_array($cur)) $cur = array();
    $prevT = isset($data['paraveda_orders_v5']['t']) ? (int)$data['paraveda_orders_v5']['t'] : 0;
    $now = (int)(microtime(true) * 1000);
    foreach ($cur as $i => $o) {
      if (!is_array($o) || !isset($o['id'])) continue;
      $id = (string)$o['id'];
      if (!isset($o['_f']) || !is_array($o['_f'])) $o['_f'] = array();
      if (isset($sent[$id])) {
        $__si = is_array($sent[$id]) ? $sent[$id] : array('raw'=>(string)$sent[$id]);
        $o['dlSent'] = 1; $o['dlAt'] = $now; $o['dlRes'] = isset($__si['raw']) ? (string)$__si['raw'] : '';
        if (!empty($__si['num'])) { $o['dlNum'] = (string)$__si['num']; $o['_f']['dlNum'] = $now; }
        if (!empty($__si['id'])) { $o['dlOrderId'] = (string)$__si['id']; $o['_f']['dlOrderId'] = $now; }
        if (!empty($__si['tracking'])) { $o['tracking'] = (string)$__si['tracking']; $o['_f']['tracking'] = $now; }
        $o['livraison'] = 'Expédier vers'; $o['_f']['livraison'] = $now;   // بعد ما تتسجل فـDigylog: Suivie = Expédier vers
        $o['_f']['dlSent'] = $now; $o['_u'] = $now; $applied++;
      } elseif (isset($failed[$id])) {
        $o['dlTries'] = (isset($o['dlTries']) ? (int)$o['dlTries'] : 0) + 1;
        $o['dlErr'] = substr((string)$failed[$id], 0, 200);
        $o['_f']['dlTries'] = $now; $o['_f']['dlErr'] = $now; $o['_u'] = $now; $applied++;
      } else continue;
      $cur[$i] = $o;
    }
    if ($applied > 0) {
      crm_backup();
      $t = max($prevT + 1, $now);
      $data['paraveda_orders_v5'] = array('t' => $t, 'd' => array_values($cur));
      $ok = crm_write_all($data);
      if ($ok) crm_journal_append('paraveda_orders_v5', $t, array_values($cur));
    }
    if ($fh) { @flock($fh, LOCK_UN); @fclose($fh); }
  }
  if ($runLock) { @flock($runLock, LOCK_UN); @fclose($runLock); }

  /* Filet de sécurité ديال الـwebhook: كل تشغيل cron كيراجع دفعة صغيرة من
     trackings المخزنين مباشرة عند Digylog. هكذا Livrée/Retournée كيتصلحو
     أوتوماتيكياً حتى إلا ضاع webhook واحد، بلا تدخل من الأدمين. */
  $polled = (!$dry && $token !== '') ? crm_dl_reconcile_known_batch(8) : array('checked'=>0, 'updated'=>0);
  crm_audit('digylog-sync | sent=' . count($sent) . ' | failed=' . count($failed) . ' | skipped=' . count($skipped) . ' | applied=' . $applied . ' | polled=' . (isset($polled['checked']) ? $polled['checked'] : 0) . ' | pollUpdated=' . (isset($polled['updated']) ? $polled['updated'] : 0));
  return array('ok'=>true, 'sent'=>count($sent), 'failed'=>count($failed), 'skipped'=>count($skipped), 'applied'=>$applied, 'polled'=>$polled, 'errors'=>$failed);
}

/* لائحة الطلبات اللي خاصها بحث عكسي بالهاتف. كنرجعو IDs فقط للواجهة؛ الهاتف
 * كيبقى فالسيرفر وما كيتعرضش فالنتيجة. */
function crm_dl_phone_candidates() {
  $data = crm_read_raw(true);
  $orders = isset($data['paraveda_orders_v5']['d']) ? crm_unwrap($data['paraveda_orders_v5']['d']) : array();
  $ids = array();
  if (is_array($orders)) foreach ($orders as $o) {
    if (!is_array($o) || !empty($o['_del'])) continue;
    if (trim((string)(isset($o['tracking']) ? $o['tracking'] : '')) !== '') continue;
    if (crm_dl_phone_norm(isset($o['telephone']) ? $o['telephone'] : '') === '') continue;
    /* الأولوية للي باينين Expédier vers، ولكن الزر يقدر يربط حتى الحالات الأخرى. */
    $ids[] = (string)$o['id'];
  }
  return array('ok'=>true, 'ids'=>$ids, 'total'=>count($ids));
}
/* كنستخرجو records اللي فيهم نفس الهاتف + tracking من أي response wrapper. */
function crm_dl_phone_records($v, $phone, &$out, $depth = 0) {
  if (!is_array($v) || $depth > 10) return;
  $assoc = array_keys($v) !== range(0, count($v) - 1);
  if ($assoc) {
    $p = crm_dl_phone_norm(crm_dl_hook_pick($v, array('phone','telephone','tel','customerPhone','customer_phone','clientPhone','client_phone','recipientPhone','recipient_phone')));
    $tr = crm_dl_hook_pick($v, array('traking','tracking','trackingId','tracking_id','trackingNumber','tracking_number','barcode'));
    if ($tr !== '' && $p === $phone) $out[strtoupper(trim($tr))] = $v;
  }
  foreach ($v as $child) if (is_array($child)) crm_dl_phone_records($child, $phone, $out, $depth + 1);
}
function crm_dl_phone_record_score($info, $order) {
  if (!is_array($info) || !is_array($order)) return 0;
  $score = 0;
  $rd = substr((string)(isset($info['createdAt']) ? $info['createdAt'] : ''), 0, 10);
  if ($rd !== '' && $rd === substr((string)(isset($order['dateCreation']) ? $order['dateCreation'] : ''), 0, 10)) $score += 4;
  if (isset($info['price']) && is_numeric($info['price']) && abs((float)$info['price'] - (float)(isset($order['prix']) ? $order['prix'] : 0)) < .01) $score += 2;
  $rc = crm_dl_hook_norm(isset($info['city']) ? $info['city'] : '');
  if ($rc !== '' && $rc === crm_dl_hook_norm(isset($order['ville']) ? $order['ville'] : '')) $score += 2;
  $rn = crm_dl_hook_norm(isset($info['name']) ? $info['name'] : '');
  if ($rn !== '' && $rn === crm_dl_hook_norm(isset($order['nom']) ? $order['nom'] : '')) $score += 1;
  return $score;
}
/* البحث العكسي اللي طلبو المستخدم: هاتف CRM → search API Digylog → Tracking.
 * كنقبلو عدة صيغ endpoint لأن نسخ seller API ماشي كلها بنفس route. أول route
 * كيرجع HTTP 200 كنعتمدو عليه لباقي الدفعة. */
function crm_dl_match_phones($requestedIds, $temporarySellerToken = '') {
  global $LOCK_FILE;
  $ids = array(); foreach ($requestedIds as $id) { $id = (string)$id; if ($id !== '') $ids[$id] = true; if (count($ids) >= 20) break; }
  if (!$ids) return array('ok'=>false, 'err'=>'no-ids');
  $cfg = crm_dl_cfg_get();
  /* الزر يقدر يبعث Session Token مباشرة بلا خطوة حفظ. كنرجعو للمحفوظ غير
     للتوافق مع النسخة السابقة. القيمة المباشرة لا تُكتب نهائياً في config. */
  $token = crm_dl_bearer_value($temporarySellerToken);
  if ($token === '') $token = isset($cfg['sellerToken']) ? trim((string)$cfg['sellerToken']) : '';
  if ($token === '') return array('ok'=>false, 'err'=>'no-seller-token');
  $data = crm_read_raw(true);
  $orders = isset($data['paraveda_orders_v5']['d']) ? crm_unwrap($data['paraveda_orders_v5']['d']) : array();
  $todo = array();
  if (is_array($orders)) foreach ($orders as $o) {
    $id = is_array($o) && isset($o['id']) ? (string)$o['id'] : '';
    if ($id !== '' && isset($ids[$id]) && empty($o['_del']) && trim((string)(isset($o['tracking']) ? $o['tracking'] : '')) === '') $todo[] = $o;
  }
  /* Route exact لقاها المستخدم من Network ديال seller.digylog.com. */
  $templates = array('/historic/orders?phone={phone}&datatype=1&countPerPage=100&currentPage=1&sort=0');
  $working = ''; $tests = array(); $found = array(); $ambiguous = 0; $checked = 0;
  foreach ($todo as $o) {
    $phone = crm_dl_phone_norm(isset($o['telephone']) ? $o['telephone'] : ''); if ($phone === '') continue;
    $variants = array($phone); if (strlen($phone) === 10 && $phone[0] === '0') $variants[] = '212' . substr($phone, 1);
    $try = $working !== '' ? array($working) : $templates; $records = array();
    foreach ($try as $tpl) {
      foreach ($variants as $pv) {
        $path = str_replace('{phone}', rawurlencode($pv), $tpl);
        list($code, $body, $err) = crm_dl_internal_http($path, $token);
        if (count($tests) < 12) $tests[] = array('path'=>str_replace(rawurlencode($pv), 'PHONE', $path), 'code'=>$code, 'err'=>$err !== '' ? substr($err,0,80) : '');
        if ($code < 200 || $code >= 300 || $body === '') continue;
        if ($working === '') $working = $tpl;
        $j = json_decode($body, true); if (is_array($j)) crm_dl_phone_records($j, $phone, $records);
        if ($records) break 2;
      }
    }
    $checked++;
    /* إلا حتى route ما رجع 2xx، باقي الهواتف غادي يعطيو نفس النتيجة؛ نوقفو
       باش ما نضربوش API بعشرات الطلبات الفارغة. */
    if ($working === '' && $checked >= 1) break;
    if (!$records) continue;
    $bestTr = ''; $bestScore = -1; $ties = 0;
    foreach ($records as $tr => $info) {
      $sc = crm_dl_phone_record_score($info, $o);
      if ($sc > $bestScore) { $bestScore=$sc; $bestTr=$tr; $ties=1; }
      elseif ($sc === $bestScore) $ties++;
    }
    if (count($records) === 1 || ($bestScore > 0 && $ties === 1)) $found[(string)$o['id']] = array('tracking'=>$bestTr, 'info'=>$records[$bestTr]);
    else $ambiguous++;
  }
  $linked=0; $updated=0;
  if ($found) {
    $fh=@fopen($LOCK_FILE,'c'); if($fh)@flock($fh,LOCK_EX);
    $data=crm_read_raw(true); $cur=isset($data['paraveda_orders_v5']['d'])?crm_unwrap($data['paraveda_orders_v5']['d']):array(); if(!is_array($cur))$cur=array();
    $prevT=isset($data['paraveda_orders_v5']['t'])?(int)$data['paraveda_orders_v5']['t']:0; $now=(int)(microtime(true)*1000);
    foreach($cur as $i=>$o){$id=is_array($o)&&isset($o['id'])?(string)$o['id']:'';if($id===''||!isset($found[$id])||trim((string)(isset($o['tracking'])?$o['tracking']:''))!=='')continue;
      if(!isset($o['_f'])||!is_array($o['_f']))$o['_f']=array();$rec=$found[$id];$info=$rec['info'];$o['tracking']=$rec['tracking'];$o['_f']['tracking']=$now;
      $st=crm_dl_hook_pick($info,array('status','statusName','status_name','orderStatus','order_status','label'));$sid=crm_dl_hook_pick($info,array('idStatus','statusId','status_id','id_status'));$liv=crm_dl_status_to_crm($sid,$st);
      $o['dlStatus']=$st;$o['dlStatusId']=$sid;$o['_f']['dlStatus']=$now;$o['_f']['dlStatusId']=$now;
      if($liv!==''&&(string)(isset($o['livraison'])?$o['livraison']:'')!==$liv){$o['livraison']=$liv;$o['_f']['livraison']=$now;$updated++;if($liv==='Livrée'&&trim((string)(isset($o['dateLiv'])?$o['dateLiv']:''))===''){$o['dateLiv']=date('Y-m-d');$o['_f']['dateLiv']=$now;}}
      $o['_u']=$now;$cur[$i]=$o;$linked++;}
    if($linked>0){crm_backup();$t=max($prevT+1,$now);$data['paraveda_orders_v5']=array('t'=>$t,'d'=>array_values($cur));$ok=crm_write_all($data);if($ok)crm_journal_append('paraveda_orders_v5',$t,array_values($cur));}
    if($fh){@flock($fh,LOCK_UN);@fclose($fh);}
  }
  crm_audit('digylog-phone-match | checked='.$checked.' | linked='.$linked.' | updated='.$updated.' | ambiguous='.$ambiguous.' | endpoint='.$working);
  return array('ok'=>true,'checked'=>$checked,'linked'=>$linked,'updated'=>$updated,'notFound'=>max(0,$checked-$linked-$ambiguous),'ambiguous'=>$ambiguous,'endpoint'=>$working,'tests'=>$tests);
}

/* إصلاح الطلبيات اللي النسخة القديمة علماتها Expédier vers من HTTP 200 ديال
 * batch بلا ما تحفظ Tracking. كنعاود نفس num وبـcheckDuplicate=1 (Digylog
 * كيرفض التكرار) والهدف الوحيد هو نسترجعو tracking من جواب existing/duplicate.
 * ما كنبدلو لا الحالة لا الطلبية إلا رجع Tracking صريح. */
function crm_dl_repair_untracked($limit = 10) {
  global $LOCK_FILE;
  $cfg = crm_dl_cfg_get();
  $token = isset($cfg['token']) ? trim((string)$cfg['token']) : '';
  if ($token === '') return array('ok'=>false, 'err'=>'no-token');
  $network = isset($cfg['network']) ? (int)$cfg['network'] : 1;
  $sentType = isset($cfg['sentType']) ? (int)$cfg['sentType'] : 0;
  $stores = isset($cfg['stores']) && is_array($cfg['stores']) ? $cfg['stores'] : array();

  $data = crm_read_raw(true);
  $orders = isset($data['paraveda_orders_v5']['d']) ? crm_unwrap($data['paraveda_orders_v5']['d']) : array();
  if (!is_array($orders)) $orders = array();
  $groups = array(); $totalUntracked = 0;
  foreach ($orders as $o) {
    if (!is_array($o) || !empty($o['_del'])) continue;
    if (crm_dl_hook_norm(isset($o['livraison']) ? $o['livraison'] : '') !== 'expedier vers') continue;
    if (trim((string)(isset($o['tracking']) ? $o['tracking'] : '')) !== '') continue;
    $totalUntracked++;
    if (array_sum(array_map('count', $groups)) >= $limit) continue;
    $ag = isset($o['agent']) ? (string)$o['agent'] : '';
    $store = isset($stores[$ag]) ? trim((string)$stores[$ag]) : '';
    if ($store === '') continue;
    $valid = true;
    foreach (array('nom','telephone','adresse','ville','produit') as $f) if (trim((string)(isset($o[$f]) ? $o[$f] : '')) === '') { $valid = false; break; }
    if ($valid) $groups[$store][] = array('id'=>(string)$o['id'], 'row'=>crm_dl_order_row($o));
  }
  $selected = 0; foreach ($groups as $rows) $selected += count($rows);
  if ($selected === 0) return array('ok'=>true, 'candidates'=>$totalUntracked, 'checked'=>0, 'recovered'=>0, 'remaining'=>$totalUntracked);

  $found = array(); $diag = array();
  foreach ($groups as $store => $rows) {
    $body = crm_dl_body($store, $network, $sentType, array_map(function($r){ return $r['row']; }, $rows));
    list($code, $resp, $err) = crm_dl_http('POST', '/orders/standard', $token, $body);
    $records = array(); $j = json_decode($resp, true);
    if ($code >= 200 && $code < 300 && is_array($j)) crm_dl_response_records($j, $records);
    foreach ($rows as $ri => $r) {
      $rr = null;
      foreach ($records as $candidate) {
        $orig = crm_dl_response_value($candidate, array('num','orderNum','order_num','externalReference','external_reference','clientReference','client_reference','reference','ref','sourceNum','source_num'));
        if ($orig !== '' && $orig === (string)$r['id']) { $rr = $candidate; break; }
      }
      if ($rr === null && count($records) === count($rows) && isset($records[$ri])) $rr = $records[$ri];
      $tr = crm_dl_response_value($rr, array('traking','tracking','trackingId','tracking_id','trackingNumber','tracking_number'));
      if ($tr !== '') $found[(string)$r['id']] = strtoupper(trim($tr));
    }
    $diag[] = array('store'=>$store, 'code'=>$code, 'rows'=>count($rows), 'records'=>count($records), 'trackings'=>count($found), 'err'=>$err !== '' ? substr($err,0,100) : '');
  }

  $recovered = 0;
  if ($found) {
    $fh = @fopen($LOCK_FILE, 'c'); if ($fh) @flock($fh, LOCK_EX);
    $data = crm_read_raw(true);
    $cur = isset($data['paraveda_orders_v5']['d']) ? crm_unwrap($data['paraveda_orders_v5']['d']) : array();
    if (!is_array($cur)) $cur = array();
    $prevT = isset($data['paraveda_orders_v5']['t']) ? (int)$data['paraveda_orders_v5']['t'] : 0;
    $now = (int)(microtime(true) * 1000);
    foreach ($cur as $i => $o) {
      $id = is_array($o) && isset($o['id']) ? (string)$o['id'] : '';
      if ($id === '' || !isset($found[$id]) || trim((string)(isset($o['tracking']) ? $o['tracking'] : '')) !== '') continue;
      if (!isset($o['_f']) || !is_array($o['_f'])) $o['_f'] = array();
      $o['tracking'] = $found[$id]; $o['_f']['tracking'] = $now; $o['_u'] = $now;
      unset($o['dlErr']); $cur[$i] = $o; $recovered++;
    }
    if ($recovered > 0) {
      crm_backup(); $t = max($prevT + 1, $now);
      $data['paraveda_orders_v5'] = array('t'=>$t, 'd'=>array_values($cur));
      $ok = crm_write_all($data); if ($ok) crm_journal_append('paraveda_orders_v5', $t, array_values($cur));
    }
    if ($fh) { @flock($fh, LOCK_UN); @fclose($fh); }
  }
  crm_audit('digylog-repair-untracked | candidates=' . $totalUntracked . ' | checked=' . $selected . ' | recovered=' . $recovered);
  return array('ok'=>true, 'candidates'=>$totalUntracked, 'checked'=>$selected, 'recovered'=>$recovered, 'remaining'=>max(0,$totalUntracked-$recovered), 'diagnostic'=>$diag);
}

/* v3.103: Digylog webhook — أي طلبية تـLivرات فـDigylog كتولي Livrée فالـCRM.
 * الرابط اللي كيتسجل فـDigylog: api.php?action=digylog_hook&token=SECRET  (بلا X-Sync-Token)
 * - handshake: {type:'subscribe', key} → كنردو {key} بحالو.
 * - كندعمو payload/data/order والحقول بأسماء مختلفة، حيت شكل الحدث كيختلف حسب نسخة Digylog.
 * - idStatus 6 أو status فيه Livrée/Delivered → Suivie = Livrée + تاريخ التسليم.
 * - المطابقة كتكون أولا بـnum ديال CRM، ومن بعد بمعرّف Digylog أو tracking.
 */
function crm_dl_hook_norm($v) {
  $v = trim((string)$v);
  $v = function_exists('mb_strtolower') ? mb_strtolower($v, 'UTF-8') : strtolower($v);
  return str_replace(array('é','è','ê','ë','à','â','ä','î','ï','ô','ö','ù','û','ü','ç'),
                     array('e','e','e','e','a','a','a','i','i','o','o','u','u','u','c'), $v);
}
function crm_dl_hook_pick($a, $keys) {
  if (!is_array($a)) return '';
  foreach ($keys as $k) {
    if (array_key_exists($k, $a) && !is_array($a[$k]) && !is_object($a[$k]) && trim((string)$a[$k]) !== '') return trim((string)$a[$k]);
  }
  return '';
}
/* الحالة النهائية فقط: "En cours ... retour" ماشي Retournée بعد، لذلك ما
 * كنبدلوش CRM حتى Digylog يقول Retournée/Returned صراحة. */
function crm_dl_status_to_crm($idStatus, $status) {
  $s = crm_dl_hook_norm($status);
  if (strpos($s, 'retourne') !== false || strpos($s, 'returned') !== false) return 'Retournée';
  if ((string)$idStatus === '6' || strpos($s, 'livr') !== false || strpos($s, 'deliver') !== false || strpos($s, 'distribu') !== false || strpos($s, 'remis') !== false) return 'Livrée';
  return '';
}
function crm_dl_hook_payload($j) {
  $p = $j;
  /* بعض نسخ Digylog كيغلفو الحدث مرة أو جوج: payload/data/order */
  for ($n = 0; $n < 3; $n++) {
    $next = null;
    foreach (array('payload','data','order') as $k) {
      if (isset($p[$k]) && is_array($p[$k]) && count($p[$k]) > 0) { $next = $p[$k]; break; }
    }
    if ($next === null) break;
    /* حقول الغلاف كتبقى متاحة إلا ما كانتش فالداخل؛ كنحيدو غير الغلاف الحالي
       قبل الدمج باش order داخل data ما يتحيدش بالغلط. */
    unset($p['payload'], $p['data'], $p['order']);
    $p = array_merge($p, $next);
  }
  return $p;
}
function crm_dl_phone_norm($v) {
  $d = preg_replace('/\D+/', '', (string)$v);
  /* +2126xxxxxxxx / 2126xxxxxxxx → 06xxxxxxxx */
  if (strlen($d) === 12 && strpos($d, '212') === 0) $d = '0' . substr($d, 3);
  return $d;
}
function crm_dl_find_customer_phone($v) {
  if (!is_array($v)) return '';
  foreach (array('phone','telephone','tel','customerPhone','customer_phone','clientPhone','client_phone','recipientPhone','recipient_phone') as $k) {
    if (isset($v[$k]) && !is_array($v[$k])) {
      $p = crm_dl_phone_norm($v[$k]);
      if (strlen($p) >= 9) return $p;
    }
  }
  foreach ($v as $child) {
    if (is_array($child)) { $p = crm_dl_find_customer_phone($child); if ($p !== '') return $p; }
  }
  return '';
}
/* الـwebhook ديال Digylog ما فيهش هاتف الزبون، وnum ديالو داخلي. فالطلبيات
 * القديمة اللي ما تخزنش فيها tracking كنجيب تفاصيل الطلبية بـGET read-only،
 * ومن بعد كنطابق بالهاتف بشكل unique. */
function crm_dl_lookup_customer_phone($num, $tracking) {
  $cfg = crm_dl_cfg_get();
  $token = isset($cfg['token']) ? trim((string)$cfg['token']) : '';
  if ($token === '') return array('phone'=>'', 'path'=>'no-token');
  $paths = array();
  if ($num !== '') {
    $q = rawurlencode($num);
    $paths[] = '/orders/' . $q;
    $paths[] = '/orders?num=' . $q;
    $paths[] = '/orders/standard/' . $q;
  }
  if ($tracking !== '') {
    $q = rawurlencode($tracking);
    /* Endpoint officiel Digylog: كيرجع infos فيها phone/name/price/status. */
    $paths[] = '/order/' . $q . '/infos';
    $paths[] = '/orders?traking=' . $q;
    $paths[] = '/orders?tracking=' . $q;
    $paths[] = '/orders/tracking/' . $q;
  }
  foreach (array_values(array_unique($paths)) as $path) {
    list($code, $body, $err) = crm_dl_http('GET', $path, $token);
    if ($code < 200 || $code >= 300 || $body === '') continue;
    $j = json_decode($body, true);
    $phone = crm_dl_find_customer_phone($j);
    if ($phone !== '') return array('phone'=>$phone, 'path'=>$path, 'info'=>$j);
  }
  return array('phone'=>'', 'path'=>'not-found', 'info'=>array());
}
function crm_dl_match_order($orders, $phone, $info, &$matches = 0) {
  $candidates = array();
  foreach ($orders as $i => $o) {
    if (!is_array($o) || !empty($o['_del'])) continue;
    if (crm_dl_phone_norm(isset($o['telephone']) ? $o['telephone'] : '') === $phone) $candidates[] = $i;
  }
  $matches = count($candidates);
  if ($matches === 1) return $candidates[0];
  if ($matches === 0 || !is_array($info)) return -1;
  $remoteDate = substr((string)(isset($info['createdAt']) ? $info['createdAt'] : ''), 0, 10);
  $remotePrice = isset($info['price']) && is_numeric($info['price']) ? (float)$info['price'] : null;
  $remoteName = crm_dl_hook_norm(isset($info['name']) ? $info['name'] : '');
  $remoteCity = crm_dl_hook_norm(isset($info['city']) ? $info['city'] : '');
  $best = -1; $bestScore = -1; $ties = 0;
  foreach ($candidates as $i) {
    $o = $orders[$i]; $score = 0;
    if ($remoteDate !== '' && substr((string)(isset($o['dateCreation']) ? $o['dateCreation'] : ''), 0, 10) === $remoteDate) $score += 4;
    if ($remotePrice !== null && abs((float)(isset($o['prix']) ? $o['prix'] : 0) - $remotePrice) < 0.01) $score += 2;
    if ($remoteCity !== '' && crm_dl_hook_norm(isset($o['ville']) ? $o['ville'] : '') === $remoteCity) $score += 2;
    if ($remoteName !== '' && crm_dl_hook_norm(isset($o['nom']) ? $o['nom'] : '') === $remoteName) $score += 1;
    if ($score > $bestScore) { $best = $i; $bestScore = $score; $ties = 1; }
    elseif ($score === $bestScore) $ties++;
  }
  return ($bestScore > 0 && $ties === 1) ? $best : -1;
}
/* كنجمع tracking حتى إلا ما كيبانش كعمود فالـCRM: جواب إنشاء الطلبية dlRes
 * كيبقى مخزن داخلياً، وغالباً فيه traking (بالغلط الإملائي ديال Digylog).
 * batch response يقدر يكون نفسو عند عدة طلبيات؛ dedupe كيتكلف به $out. */
function crm_dl_extract_trackings($value, &$out, $depth = 0) {
  if ($depth > 8) return;
  if (is_array($value)) {
    foreach ($value as $k => $v) {
      $kn = crm_dl_hook_norm($k);
      if (!is_array($v) && in_array($kn, array('tracking','traking','trackingid','trackingnumber','barcode'), true)) {
        $tr = strtoupper(trim((string)$v));
        if (preg_match('/^[A-Z0-9_-]{5,40}$/', $tr)) $out[$tr] = true;
      }
      crm_dl_extract_trackings($v, $out, $depth + 1);
    }
    return;
  }
  if (!is_string($value) || $value === '') return;
  $j = json_decode($value, true);
  if (is_array($j)) crm_dl_extract_trackings($j, $out, $depth + 1);
  /* حتى إلا كان dlRes مقطوع فـ500 حرف، tracking غالباً باقي واضح. */
  if (preg_match_all('/\bS(?=[A-Z0-9_-]{8,20}\b)(?=[A-Z0-9_-]*[0-9])[A-Z0-9_-]{8,20}\b/', strtoupper($value), $m)) {
    foreach ($m[0] as $tr) $out[$tr] = true;
  }
}
/* جميع أرقام Digylog الموجودة داخلياً: tracking fields + أجوبة الإرسال dlRes.
 * فالاسترجاع الشامل كنزيدو حتى trackings ديال webhooks من audit.log. */
function crm_dl_known_trackings($onlyNonFinal = false) {
  global $AUDIT_FILE;
  $data = crm_read_raw(true);
  $orders = isset($data['paraveda_orders_v5']['d']) ? crm_unwrap($data['paraveda_orders_v5']['d']) : array();
  if (!is_array($orders)) return array();
  $out = array();
  foreach ($orders as $o) {
    if (!is_array($o) || !empty($o['_del'])) continue;
    if ($onlyNonFinal) {
      $liv = crm_dl_hook_norm(isset($o['livraison']) ? $o['livraison'] : '');
      if (strpos($liv, 'livr') !== false || strpos($liv, 'retour') !== false) continue;
    }
    foreach (array('tracking','dlTracking','digylogTracking') as $k) {
      if (isset($o[$k])) crm_dl_extract_trackings(array($k => $o[$k]), $out);
    }
    if (isset($o['dlRes'])) crm_dl_extract_trackings($o['dlRes'], $out);
  }
  if (!$onlyNonFinal && is_file($AUDIT_FILE)) {
    /* ما نحتاجوش نفهمو شكل كل نسخة webhook: كنستخرجو أرقام S... مباشرة. */
    $audit = (string)@file_get_contents($AUDIT_FILE);
    if (strlen($audit) > 5 * 1024 * 1024) $audit = substr($audit, -5 * 1024 * 1024);
    crm_dl_extract_trackings($audit, $out);
  }
  return array_keys($out);
}
/* Digylog seller API كيختلف حسب نسخة الحساب: بعض الحسابات كتدعم GET /orders
 * بpagination رغم أن الوثائق العامة كتركز على POST. كنجربو الصيغ المعروفة
 * read-only، وأول صيغة كترد Trackings كنكمّلو صفحاتها حتى ما يبقى جديد. */
function crm_dl_remote_trackings() {
  $cfg = crm_dl_cfg_get();
  $token = isset($cfg['token']) ? trim((string)$cfg['token']) : '';
  if ($token === '') return array('trackings'=>array(), 'count'=>0, 'endpoint'=>'', 'tests'=>array('no-token'));
  $templates = array(
    '/orders?page={page}&limit=250',
    '/orders?page={page}&perPage=250',
    '/orders?page={page}&per_page=250',
    '/orders?currentPage={page}&pageSize=250',
    '/orders/standard?page={page}&limit=250',
    '/orders/list?page={page}&limit=250',
    '/orders'
  );
  $tests = array(); $best = array(); $chosen = '';
  foreach ($templates as $tpl) {
    $path = str_replace('{page}', '1', $tpl);
    list($code, $body, $err) = crm_dl_http('GET', $path, $token);
    $found = array();
    if ($code >= 200 && $code < 300 && $body !== '') crm_dl_extract_trackings($body, $found);
    $tests[] = array('path'=>$path, 'code'=>$code, 'found'=>count($found), 'err'=>$err !== '' ? substr($err, 0, 80) : '');
    if (count($found) > 0) { $best = $found; $chosen = $tpl; break; }
  }
  if ($chosen === '') return array('trackings'=>array(), 'count'=>0, 'endpoint'=>'', 'tests'=>$tests);
  /* pagination: كنوقفو ملي صفحة ما تزيد حتى tracking أو نوصلو للسقف الآمن. */
  if (strpos($chosen, '{page}') !== false) {
    for ($page = 2; $page <= 20 && count($best) < 5000; $page++) {
      $path = str_replace('{page}', (string)$page, $chosen);
      list($code, $body, $err) = crm_dl_http('GET', $path, $token);
      if ($code < 200 || $code >= 300 || $body === '') break;
      $found = array(); crm_dl_extract_trackings($body, $found);
      $before = count($best); foreach ($found as $tr => $yes) $best[$tr] = true;
      if (count($best) === $before) break;
    }
  }
  return array('trackings'=>array_keys($best), 'count'=>count($best), 'endpoint'=>$chosen, 'tests'=>$tests);
}
/* كتراجع دفعة مختلفة مع كل cron. 8 فقط باش ما نطولوش execution ديال shared
 * hosting؛ cursor كيدور حتى تتراجع جميع الطلبيات غير النهائية. */
function crm_dl_reconcile_known_batch($limit = 8) {
  $all = crm_dl_known_trackings(true);
  $total = count($all);
  if ($total === 0) return array('ok'=>true, 'checked'=>0, 'pending'=>0, 'updated'=>0);
  $cfg = crm_dl_cfg_get();
  $cursor = isset($cfg['pollCursor']) ? max(0, (int)$cfg['pollCursor']) : 0;
  if ($cursor >= $total) $cursor = 0;
  $take = min(max(1, (int)$limit), $total);
  $batch = array();
  for ($i = 0; $i < $take; $i++) $batch[] = $all[($cursor + $i) % $total];
  $cfg['pollCursor'] = ($cursor + $take) % max(1, $total);
  crm_dl_cfg_set($cfg);
  $r = crm_dl_reconcile_recent($batch);
  $r['checked'] = count($batch); $r['pending'] = $total;
  return $r;
}

/* كيرجع يعالج آخر webhooks اللي وصلو قبل الإصلاح وكانو found=false. كيتشغل
 * مع زر اختبار الاتصال، باش Livrée/Retournée القديمة تلحق بالـCRM بلا انتظار حدث جديد. */
function crm_dl_reconcile_recent($requestedTrackings = array()) {
  global $AUDIT_FILE, $LOCK_FILE;
  $events = array();
  /* الاسترجاع اليدوي: tracking واحد فكل سطر. الحالة والهاتف كنجيبوهم مباشرة
     من endpoint الرسمي /order/{tracking}/infos. */
  if (is_array($requestedTrackings) && count($requestedTrackings) > 0) {
    foreach ($requestedTrackings as $tracking) {
      $tracking = strtoupper(trim((string)$tracking));
      if ($tracking !== '' && preg_match('/^[A-Z0-9_-]{5,40}$/', $tracking)) $events[$tracking] = array('tracking'=>$tracking, 'status'=>'', 'idStatus'=>'', 'livraison'=>'');
      if (count($events) >= 100) break;
    }
  } else {
    if (!is_file($AUDIT_FILE)) return array('ok'=>true, 'events'=>0, 'updated'=>0);
    /* نقراو audit.log كامل (حتى 2MB فقط) لأن أحداث Livrée تقدر تكون أقدم
       من آخر 1200 سطر ملي كاينين webhooks بزاف. */
    $lines = explode("\n", (string)@file_get_contents($AUDIT_FILE));
    foreach ($lines as $line) {
      $mark = strpos($line, 'digylog-hook-raw |');
      if ($mark === false) continue;
      $jsonAt = strpos($line, ' | {', $mark);
      if ($jsonAt === false) continue;
      $j = json_decode(substr($line, $jsonAt + 3), true);
      if (!is_array($j)) continue;
      $p = crm_dl_hook_payload($j);
      $tracking = crm_dl_hook_pick($p, array('traking','tracking','trackingId','tracking_id','trackingNumber','tracking_number','barcode'));
      $status = crm_dl_hook_pick($p, array('status','statusName','status_name','orderStatus','order_status','label'));
      $idStatus = crm_dl_hook_pick($p, array('idStatus','statusId','status_id','id_status'));
      $liv = crm_dl_status_to_crm($idStatus, $status);
      if ($tracking !== '' && $liv !== '') $events[$tracking] = array('tracking'=>$tracking, 'status'=>$status, 'idStatus'=>$idStatus, 'livraison'=>$liv);
    }
    if (count($events) > 100) $events = array_slice($events, -100, null, true);
  }
  $resolved = array();
  foreach ($events as $tracking => $event) {
    $look = crm_dl_lookup_customer_phone('', $tracking);
    if (empty($look['phone'])) continue;
    $info = isset($look['info']) && is_array($look['info']) ? $look['info'] : array();
    /* فالإدخال اليدوي الحالة كتجي من Digylog، ماشي من المستخدم. */
    if ($event['status'] === '') $event['status'] = crm_dl_hook_pick($info, array('status','statusName','status_name','orderStatus','order_status','label'));
    if ($event['idStatus'] === '') $event['idStatus'] = crm_dl_hook_pick($info, array('idStatus','statusId','status_id','id_status'));
    if ($event['livraison'] === '') $event['livraison'] = crm_dl_status_to_crm($event['idStatus'], $event['status']);
    /* حتى الحالات غير النهائية كنربطو tracking ديالها مع الطلبية. غير Suivie
       ما كنبدلوهاش حتى تكون Livrée ولا Retournée النهائية. */
    $event['phone'] = $look['phone']; $event['info'] = $info; $resolved[] = $event;
  }
  if (!$resolved) return array('ok'=>true, 'events'=>count($events), 'resolved'=>0, 'linked'=>0, 'updated'=>0);
  $fh = @fopen($LOCK_FILE, 'c'); if ($fh) @flock($fh, LOCK_EX);
  $data = crm_read_raw(true);
  $cur = isset($data['paraveda_orders_v5']['d']) ? crm_unwrap($data['paraveda_orders_v5']['d']) : array();
  if (!is_array($cur)) $cur = array();
  $prevT = isset($data['paraveda_orders_v5']['t']) ? (int)$data['paraveda_orders_v5']['t'] : 0;
  $updated = 0; $linked = 0; $applied = 0; $ambiguous = 0; $now = (int)(microtime(true) * 1000);
  foreach ($resolved as $event) {
    /* Tracking المخزن كيربح أولاً؛ إلا مازال ما مربوطش كنطابق بالهاتف ثم
       الاسم/المدينة/التاريخ/الثمن. */
    $hit = -1; $trackingMatches = 0;
    foreach ($cur as $ci => $co) {
      if (!is_array($co) || !empty($co['_del'])) continue;
      if (strtoupper(trim((string)(isset($co['tracking']) ? $co['tracking'] : ''))) === $event['tracking']) { $hit = $ci; $trackingMatches++; }
    }
    $matches = 0;
    if ($trackingMatches !== 1) $hit = crm_dl_match_order($cur, $event['phone'], $event['info'], $matches);
    if ($hit < 0) { if ($matches > 1) $ambiguous++; continue; }
    $o = $cur[$hit];
    if (!isset($o['_f']) || !is_array($o['_f'])) $o['_f'] = array();
    $oldTracking = strtoupper(trim((string)(isset($o['tracking']) ? $o['tracking'] : '')));
    $statusChanged = $event['livraison'] !== '' && (string)(isset($o['livraison']) ? $o['livraison'] : '') !== $event['livraison'];
    $rowChanged = $oldTracking !== $event['tracking']
      || (string)(isset($o['dlStatus']) ? $o['dlStatus'] : '') !== (string)$event['status']
      || (string)(isset($o['dlStatusId']) ? $o['dlStatusId'] : '') !== (string)$event['idStatus']
      || $statusChanged;
    if ($event['livraison'] === 'Livrée' && trim((string)(isset($o['dateLiv']) ? $o['dateLiv'] : '')) === '') $rowChanged = true;
    if (!$rowChanged) continue;
    if ($event['livraison'] !== '') { $o['livraison'] = $event['livraison']; $o['_f']['livraison'] = $now; }
    $o['tracking'] = $event['tracking']; $o['_f']['tracking'] = $now;
    $o['dlStatus'] = $event['status']; $o['dlStatusId'] = $event['idStatus']; $o['dlStatusAt'] = $now;
    $o['_f']['dlStatus'] = $now; $o['_f']['dlStatusId'] = $now;
    if ($event['livraison'] === 'Livrée' && trim((string)(isset($o['dateLiv']) ? $o['dateLiv'] : '')) === '') { $o['dateLiv'] = date('Y-m-d'); $o['_f']['dateLiv'] = $now; }
    $o['_u'] = $now; $cur[$hit] = $o; $applied++;
    if ($oldTracking !== $event['tracking']) $linked++;
    if ($statusChanged) $updated++;
  }
  if ($applied > 0) {
    crm_backup(); $t = max($prevT + 1, $now);
    $data['paraveda_orders_v5'] = array('t'=>$t, 'd'=>array_values($cur));
    $ok = crm_write_all($data); if ($ok) crm_journal_append('paraveda_orders_v5', $t, array_values($cur));
  }
  if ($fh) { @flock($fh, LOCK_UN); @fclose($fh); }
  crm_audit('digylog-reconcile | events=' . count($events) . ' | resolved=' . count($resolved) . ' | linked=' . $linked . ' | updated=' . $updated . ' | ambiguous=' . $ambiguous);
  return array('ok'=>true, 'events'=>count($events), 'resolved'=>count($resolved), 'linked'=>$linked, 'updated'=>$updated, 'ambiguous'=>$ambiguous);
}
function crm_dl_hook() {
  global $SECRET, $LOCK_FILE;
  $tk = isset($_GET['token']) ? (string)$_GET['token'] : '';
  if (!hash_equals($SECRET, $tk)) crm_out(array('ok'=>false, 'err'=>'token'), 403);
  $rawHook = (string)file_get_contents('php://input');
  /* ما نسجلوش معلومات الزبون كاملة فالـaudit؛ غير أول 600 حرف للتشخيص المؤقت. */
  crm_audit('digylog-hook-raw | len=' . strlen($rawHook) . ' | ' . substr(preg_replace('/\s+/', ' ', $rawHook), 0, 600));
  $j = json_decode($rawHook, true);
  if (!is_array($j)) crm_out(array('ok'=>false, 'err'=>'bad-json'), 400);
  if (isset($j['type']) && crm_dl_hook_norm($j['type']) === 'subscribe' && isset($j['key'])) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array('key' => (string)$j['key']), JSON_UNESCAPED_UNICODE);
    exit;
  }

  $p = crm_dl_hook_payload($j);
  $ev = crm_dl_hook_pick($j, array('eventType','event_type','event','type','action'));
  if ($ev === '') $ev = crm_dl_hook_pick($p, array('eventType','event_type','event','type','action'));
  $evNorm = str_replace(array('_','.'), '-', crm_dl_hook_norm($ev));
  /* إذا جا حدث واضح وماشي ديال تبدل الحالة، نتجاهلو. الحدث بلا اسم كنقبلوه إلا فيه status. */
  $statusProbe = crm_dl_hook_pick($p, array('status','statusName','status_name','orderStatus','order_status','label'));
  if ($evNorm !== '' && strpos($evNorm, 'status') === false && strpos($evNorm, 'order') === false) crm_out(array('ok'=>true, 'ignored'=>$ev));
  if ($evNorm === '' && $statusProbe === '') crm_out(array('ok'=>true, 'ignored'=>'no-event-or-status'));

  $num = crm_dl_hook_pick($p, array('num','orderNum','order_num','externalId','external_id','externalReference','external_reference','reference','ref','clientReference','client_reference'));
  $idSt = crm_dl_hook_pick($p, array('idStatus','statusId','status_id','id_status'));
  $st = $statusProbe;
  $dlId = crm_dl_hook_pick($p, array('idOrder','orderId','order_id','id'));
  /* Digylog كيرسلها فعلياً باسم traking (بلا c)؛ كنقبلو الاسمين. */
  $tracking = crm_dl_hook_pick($p, array('traking','tracking','trackingId','tracking_id','trackingNumber','tracking_number','barcode'));
  if ($num === '' && $dlId === '' && $tracking === '') crm_out(array('ok'=>true, 'ignored'=>'no-order-reference'));

  $newLiv = crm_dl_status_to_crm($idSt, $st);

  $fh = @fopen($LOCK_FILE, 'c'); if ($fh) @flock($fh, LOCK_EX);
  $data = crm_read_raw(true);
  $cur = isset($data['paraveda_orders_v5']['d']) ? crm_unwrap($data['paraveda_orders_v5']['d']) : array();
  if (!is_array($cur)) $cur = array();
  $prevT = isset($data['paraveda_orders_v5']['t']) ? (int)$data['paraveda_orders_v5']['t'] : 0;
  $hit = -1; $matchedBy = '';

  /* 1) num/reference اللي صيفطناه لـDigylog هو id ديال الطلبية فالـCRM. */
  if ($num !== '') foreach ($cur as $i => $o) {
    if (is_array($o) && empty($o['_del']) && isset($o['id']) && (string)$o['id'] === $num) { $hit = $i; $matchedBy = 'num'; break; }
  }
  /* 2) num ديال الـwebhook هو معرّف Digylog (ماشي ديما num اللي صيفطناه)،
     أو id منفصل حسب نسخة الـAPI. كنقلبو بجوج فالمعرّفات اللي خزّناها. */
  $__dlRefs = array_values(array_filter(array($num, $dlId), function($v) { return $v !== ''; }));
  if ($hit < 0 && count($__dlRefs) > 0) foreach ($cur as $i => $o) {
    if (!is_array($o) || !empty($o['_del'])) continue;
    foreach (array('dlOrderId','digylogId','dlId','dlNum') as $k) {
      if (isset($o[$k]) && in_array((string)$o[$k], $__dlRefs, true)) { $hit = $i; $matchedBy = $k; break 2; }
    }
  }
  /* 3) tracking unique كحل احتياطي آمن. */
  if ($hit < 0 && $tracking !== '') {
    $candidate = -1; $matches = 0;
    foreach ($cur as $i => $o) {
      if (is_array($o) && empty($o['_del']) && isset($o['tracking']) && trim((string)$o['tracking']) === $tracking) { $candidate = $i; $matches++; }
    }
    if ($matches === 1) { $hit = $candidate; $matchedBy = 'tracking'; }
  }
  /* 4) الطلبية القديمة ما عندها لا tracking لا dlNum فالـCRM: كنطلقو اللوك،
     كنجيبوا تفاصيلها من Digylog، ومن بعد كنطابقو بالهاتف unique. */
  if ($hit < 0) {
    if ($fh) { @flock($fh, LOCK_UN); @fclose($fh); $fh = null; }
    $__look = crm_dl_lookup_customer_phone($num, $tracking);
    $__phone = isset($__look['phone']) ? (string)$__look['phone'] : '';
    if ($__phone !== '') {
      $fh = @fopen($LOCK_FILE, 'c'); if ($fh) @flock($fh, LOCK_EX);
      $data = crm_read_raw(true);
      $cur = isset($data['paraveda_orders_v5']['d']) ? crm_unwrap($data['paraveda_orders_v5']['d']) : array();
      if (!is_array($cur)) $cur = array();
      $prevT = isset($data['paraveda_orders_v5']['t']) ? (int)$data['paraveda_orders_v5']['t'] : 0;
      $matches = 0;
      $candidate = crm_dl_match_order($cur, $__phone, isset($__look['info']) ? $__look['info'] : array(), $matches);
      if ($candidate >= 0) { $hit = $candidate; $matchedBy = 'digylog-api-phone'; }
      crm_audit('digylog-lookup | path=' . (isset($__look['path']) ? $__look['path'] : '') . ' | phoneTail=' . substr($__phone, -4) . ' | matches=' . $matches . ' | matched=' . ($candidate >= 0 ? 1 : 0));
    }
  }
  if ($hit < 0) {
    if ($fh) { @flock($fh, LOCK_UN); @fclose($fh); }
    crm_audit('digylog-hook-miss | num=' . $num . ' | dlId=' . $dlId . ' | tracking=' . $tracking . ' | status=' . $st);
    crm_out(array('ok'=>true, 'found'=>false, 'num'=>$num, 'lookup'=>(isset($__look['path']) ? $__look['path'] : 'not-run')));
  }

  $now = (int)(microtime(true) * 1000);
  $o = $cur[$hit];
  if (!isset($o['_f']) || !is_array($o['_f'])) $o['_f'] = array();
  $before = json_encode($o, JSON_UNESCAPED_UNICODE);
  $o['dlStatus'] = $st;
  $o['dlStatusId'] = $idSt;
  $o['dlStatusAt'] = $now;
  $o['_f']['dlStatus'] = $now; $o['_f']['dlStatusId'] = $now;
  if ($num !== '') { $o['dlNum'] = $num; $o['_f']['dlNum'] = $now; }
  if ($dlId !== '') { $o['dlOrderId'] = $dlId; $o['_f']['dlOrderId'] = $now; }
  if ($tracking !== '' && trim((string)(isset($o['tracking']) ? $o['tracking'] : '')) === '') { $o['tracking'] = $tracking; $o['_f']['tracking'] = $now; }
  if ($newLiv !== '') {
    $o['livraison'] = $newLiv; $o['_f']['livraison'] = $now;
    if ($newLiv === 'Livrée' && trim((string)(isset($o['dateLiv']) ? $o['dateLiv'] : '')) === '') {
      $o['dateLiv'] = date('Y-m-d'); $o['_f']['dateLiv'] = $now;
    }
  }
  $changed = ($before !== json_encode($o, JSON_UNESCAPED_UNICODE));
  if ($changed) $o['_u'] = $now;
  $cur[$hit] = $o;
  $ok = true;
  if ($changed) {
    crm_backup();
    $t = max($prevT + 1, $now);
    $data['paraveda_orders_v5'] = array('t' => $t, 'd' => array_values($cur));
    $ok = crm_write_all($data);
    if ($ok) crm_journal_append('paraveda_orders_v5', $t, array_values($cur));
  }
  if ($fh) { @flock($fh, LOCK_UN); @fclose($fh); }
  crm_audit('digylog-hook | num=' . $num . ' | matchedBy=' . $matchedBy . ' | idStatus=' . $idSt . ' | status=' . $st . ' | livraison=' . $newLiv . ' | changed=' . ($changed ? 1 : 0));
  crm_out(array('ok'=>(bool)$ok, 'found'=>true, 'matchedBy'=>$matchedBy, 'livraison'=>(isset($o['livraison']) ? $o['livraison'] : '')));
}
if (isset($_GET['action']) && $_GET['action'] === 'digylog_hook') crm_dl_hook();

$m = $_SERVER['REQUEST_METHOD'] ?? 'GET';

/* ---------- GET: full snapshot ---------- */
if ($m === 'GET') {
  // v3.101: cron ديال Digylog: api.php?action=digylog_sync&token=...
  if (isset($_GET['action']) && $_GET['action'] === 'digylog_sync') {
    if (!hash_equals($SECRET, crm_token())) crm_out(array('ok'=>false, 'err'=>'token'), 403);
    crm_out(crm_dl_run(false));
  }
  // v3.41: la lecture exige aussi le token (avant: n'importe qui avec l'URL téléchargeait tous les clients)
  if (!hash_equals($SECRET, crm_token())) crm_out(array('ok'=>false, 'err'=>'token'), 403);

  /* PERF v3.90 — أهم إصلاح فالسيرفر.
   * قبل: كل جهاز كيدير GET كل 5 ثواني وكيحمّل 1.1MB حتى إلا ما تبدل والو.
   *      = 720 طلب/ساعة × 1.1MB = ~800MB فالساعة لكل مستخدم.
   * دابا: بصمة رخيصة (stat) → إلا ما تبدل والو كنرجعو 304 بلا ما نقراو حتى ملف
   *      وبلا ما نصيفطو حتى بايت. المتصفح ما كيديرش parse ولا localStorage ولا
   *      إعادة رسم — وهادا هو لي كان كيبلوكي الشاشة كل 5 ثواني. */
  /* ================================================================
   * v3.91 — واجهة خفيفة لـ Google Sheets
   *   api.php?export=adspend&token=...  → المصاريف الخام (للتحرير فالشيت)
   *   api.php?export=perf&token=...     → جدول الأداء محسوب (للقراءة فقط)
   * كترجع غير لي محتاج الشيت (بضع كيلوبايتات) عوض 1.1 ميغا.
   * ================================================================ */
  if (isset($_GET['pushkey'])) {   // v3.98: المفتاح العام ديال Web Push
    $__pk = crm_push_keys();
    crm_out($__pk ? array('ok'=>true, 'key'=>$__pk['pub']) : array('ok'=>false, 'err'=>'no-vapid-keys'), $__pk ? 200 : 500);
  }
  if (isset($_GET['export'])) {
    $__what = (string)$_GET['export'];
    $__d    = crm_read_raw();
    $__ads  = isset($__d['paraveda_adspend_v1']['d']) ? crm_unwrap($__d['paraveda_adspend_v1']['d']) : array();
    if (!is_array($__ads)) $__ads = array();
    $__adsT = isset($__d['paraveda_adspend_v1']['t']) ? (int)$__d['paraveda_adspend_v1']['t'] : 0;
    $__rs   = isset($__d['paraveda_reset_v1']['t'])   ? (int)$__d['paraveda_reset_v1']['t']   : 0;

    if ($__what === 'adspend') {
      crm_out(array('ok'=>true, 't'=>$__adsT, 'rs'=>$__rs, 'rows'=>array_values($__ads)));
    }

    if ($__what === 'perf') {
      $__ord = isset($__d['paraveda_orders_v5']['d']) ? crm_unwrap($__d['paraveda_orders_v5']['d']) : array();
      if (!is_array($__ord)) $__ord = array();
      /* فهرسة الطلبيات بالتاريخ — بلا هادشي كنديرو 109 × 1400 مقارنة */
      $__byDate = array();
      foreach ($__ord as $o) {
        if (!is_array($o) || !empty($o['_del'])) continue;
        $dt = isset($o['dateCreation']) ? (string)$o['dateCreation'] : '';
        if ($dt === '') continue;
        $__byDate[$dt][] = $o;
      }
      $__norm = function($v) { return strtolower(trim((string)$v)); };
      $__rows = array();
      foreach ($__ads as $a) {
        if (!is_array($a)) continue;
        $aDate = isset($a['date'])    ? (string)$a['date']    : '';
        $aAg   = isset($a['agent'])   ? (string)$a['agent']   : '';
        $aPr   = isset($a['produit']) ? (string)$a['produit'] : '';
        $aSrc  = isset($a['source'])  ? (string)$a['source']  : '';
        $amt   = isset($a['amount'])  ? (float)$a['amount']   : 0;

        $cnt = 0; $conf = 0; $livre = 0; $retour = 0; $ca = 0;
        $pool = isset($__byDate[$aDate]) ? $__byDate[$aDate] : array();
        foreach ($pool as $o) {
          /* نفس منطق المطابقة ديال صفحة Dashboard performance بالضبط */
          if ($aAg !== '' && $__norm(isset($o['agent']) ? $o['agent'] : '') !== $__norm($aAg)) continue;
          if ($aPr !== '' && $__norm(isset($o['produit']) ? $o['produit'] : '') !== $__norm($aPr)) continue;
          if ($aAg === '' && $aSrc !== ''
              && $__norm(isset($o['originLead']) ? $o['originLead'] : '') !== $__norm($aSrc)) continue;

          $cnt++;
          $st = isset($o['statut'])    ? (string)$o['statut']    : '';
          $lv = isset($o['livraison']) ? (string)$o['livraison'] : '';
          if ($st === 'Confirmé') $conf++;
          if ($lv === 'Livrée' || $lv === 'Rechange')   { $livre++;  $ca += isset($o['prix']) ? (float)$o['prix'] : 0; }
          if ($lv === 'Retour' || $lv === 'Retournée' || $lv === 'Remboursé')  { $retour++; }
        }
        $__rows[] = array(
          'id'      => isset($a['id']) ? $a['id'] : '',
          'date'    => $aDate,
          'agent'   => $aAg,
          'produit' => $aPr,
          'source'  => $aSrc,
          'amount'  => $amt,
          'count'   => $cnt,
          'conf'    => $conf,
          'livre'   => $livre,
          'retour'  => $retour,
          'ca'      => $ca,
          'cpl'     => $cnt > 0 ? round($amt / $cnt, 2) : '',
        );
      }
      crm_out(array('ok'=>true, 't'=>$__adsT, 'rs'=>$__rs, 'rows'=>$__rows));
    }

    if ($__what === 'orders') {
      /* v3.92: الطلبيات الحية للـ Google Sheet.
       * كنرجعو صفوف (arrays) ماشي objects — الحجم كينقص ~60% وكيدخل
       * مباشرة لـ setValues() بلا تحويل. */
      $__cols = array('id','dateCreation','dateConfirmation','statut','remarques','idCmd',
                      'nom','telephone','ville','adresse','qte','prix','produit','livraison',
                      'upsell','carousell','agent','link','carosellFlag','originLead',
                      'commission','fees','livreur','tracking','dateExp','dateLiv','motif');
      $__since = isset($_GET['since']) ? trim((string)$_GET['since']) : '';
      $__ord = isset($__d['paraveda_orders_v5']['d']) ? crm_unwrap($__d['paraveda_orders_v5']['d']) : array();
      if (!is_array($__ord)) $__ord = array();
      $__out = array();
      foreach ($__ord as $o) {
        if (!is_array($o) || !empty($o['_del'])) continue;              // الممسوحة ما كتبانش
        if ($__since !== '' && (string)(isset($o['dateCreation']) ? $o['dateCreation'] : '') < $__since) continue;
        $row = array();
        foreach ($__cols as $c) {
          $v = isset($o[$c]) ? $o[$c] : '';
          if (is_array($v) || is_object($v)) $v = '';
          $row[] = $v;
        }
        $__out[] = $row;
      }
      /* الأحدث فاللول (نفس ترتيب الـCRM) */
      usort($__out, function($a, $b) {
        if ($a[1] === $b[1]) return ((float)$b[0] < (float)$a[0]) ? -1 : (((float)$b[0] > (float)$a[0]) ? 1 : 0);
        return strcmp((string)$b[1], (string)$a[1]);
      });
      crm_out(array(
        'ok'   => true,
        't'    => isset($__d['paraveda_orders_v5']['t']) ? (int)$__d['paraveda_orders_v5']['t'] : 0,
        'cols' => $__cols,
        'rows' => $__out,
      ));
    }

    if ($__what === 'stats') {
      /* v3.93: تشخيص — كيعطي الأرقام ديال الطلبيات بلا ما يحمّل الداتا كاملة */
      $__ord = isset($__d['paraveda_orders_v5']['d']) ? crm_unwrap($__d['paraveda_orders_v5']['d']) : array();
      if (!is_array($__ord)) $__ord = array();
      $live = 0; $del = 0; $nodate = 0; $bymonth = array(); $min = ''; $max = '';
      foreach ($__ord as $o) {
        if (!is_array($o)) continue;
        if (!empty($o['_del'])) { $del++; continue; }
        $live++;
        $dt = isset($o['dateCreation']) ? (string)$o['dateCreation'] : '';
        if ($dt === '') { $nodate++; continue; }
        $m = substr($dt, 0, 7);
        $bymonth[$m] = (isset($bymonth[$m]) ? $bymonth[$m] : 0) + 1;
        if ($min === '' || $dt < $min) $min = $dt;
        if ($max === '' || $dt > $max) $max = $dt;
      }
      ksort($bymonth);
      crm_out(array(
        'ok'            => true,
        'total_rows'    => count($__ord),
        'live_orders'   => $live,
        'deleted'       => $del,
        'without_date'  => $nodate,
        'oldest'        => $min,
        'newest'        => $max,
        'by_month'      => $bymonth,
        'data_file_kb'  => round(@filesize($DATA_FILE) / 1024),
        'journal_kb'    => round(@filesize($JOURNAL) / 1024),
        'orders_t'      => isset($__d['paraveda_orders_v5']['t']) ? (int)$__d['paraveda_orders_v5']['t'] : 0,
      ));
    }

    if ($__what === 'csv') {
      /* v3.95: CSV مباشر لـ Google Sheets عبر IMPORTDATA() — بلا Apps Script.
       * الأعمدة بنفس ترتيب ورقة COMONDES: A حتى M. بلا رأس. */
      $__ord = isset($__d['paraveda_orders_v5']['d']) ? crm_unwrap($__d['paraveda_orders_v5']['d']) : array();
      if (!is_array($__ord)) $__ord = array();
      $__c = array('dateCreation','dateConfirmation','statut','remarques','idCmd','nom',
                   'telephone','ville','adresse','qte','prix','produit','livraison');
      /* v3.96: &cols=upsell  ولا  &cols=agent,link  → كيرجع غير داك/هادوك الأعمدة،
       * بنفس ترتيب السطور. مفيد للأعمدة لي جايين بعد M فالشيت. */
      if (!empty($_GET['cols'])) {
        $__allf = array('id','dateCreation','dateConfirmation','statut','remarques','idCmd','nom',
                        'telephone','ville','adresse','qte','prix','produit','livraison','upsell',
                        'carousell','agent','link','carosellFlag','originLead','commission','fees',
                        'livreur','tracking','dateExp','dateLiv','motif');
        $__sel = array();
        foreach (explode(',', (string)$_GET['cols']) as $__r) {
          $__r = trim($__r);
          if ($__r === '') continue;
          foreach ($__allf as $__f) { if (strcasecmp($__f, $__r) === 0) { $__sel[] = $__f; break; } }
        }
        if (!$__sel) crm_out(array('ok'=>false,'err'=>'bad-cols','allowed'=>$__allf), 400);
        $__c = $__sel;
      }
      $__rows = array();
      foreach ($__ord as $o) {
        if (!is_array($o) || !empty($o['_del'])) continue;
        $__rows[] = $o;
      }
      usort($__rows, function($a, $b) {
        $x = isset($a['dateCreation']) ? (string)$a['dateCreation'] : '';
        $y = isset($b['dateCreation']) ? (string)$b['dateCreation'] : '';
        if ($x === $y) {
          $ai = isset($a['id']) ? (float)$a['id'] : 0; $bi = isset($b['id']) ? (float)$b['id'] : 0;
          return ($bi < $ai) ? -1 : (($bi > $ai) ? 1 : 0);
        }
        return strcmp($y, $x);
      });
      $out = '';
      foreach ($__rows as $o) {
        $line = array();
        foreach ($__c as $c) {
          $v = isset($o[$c]) ? $o[$c] : '';
          if (is_array($v) || is_object($v)) $v = '';
          $v = (string)$v;
          /* الهاتف: فراغ رفيع فاللول باش Google Sheets ما يحيدش الصفر */
          /* &plain=1 كيحيد الحماية إلا كان عمود الهاتف معمول "نص عادي" فالشيت */
          if ($c === 'telephone' && $v !== '' && $v[0] === '0' && empty($_GET['plain']))
            $v = "\xE2\x80\x8B" . $v;
          $line[] = '"' . str_replace('"', '""', $v) . '"';
        }
        $out .= implode(',', $line) . "\r\n";
      }
      if (!headers_sent()) {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: inline; filename="commandes.csv"');
      }
      echo $out;
      exit;
    }

    crm_out(array('ok'=>false, 'err'=>'unknown-export'), 400);
  }

  $__sig  = crm_data_sig();
  $__inm  = trim((string)($_SERVER['HTTP_IF_NONE_MATCH'] ?? ''));
  $__hit  = crm_etag_cached($__sig);
  if ($__hit !== null && $__inm !== '' && ($__inm === $__hit || $__inm === 'W/' . $__hit)) {
    header('ETag: ' . $__hit);
    http_response_code(304);
    exit;
  }

  $data = crm_read_raw();
  // normalise on the way out so old corrupted entries never reach the browser
  foreach ($data as $k => $v) {
    if (is_array($v) && array_key_exists('d', $v)) { $data[$k]['d'] = crm_unwrap($v['d']); }
  }
  // v3.83: حصر السجل فـ 400 عملية الأخيرة باش أجهزة المتصفح ما تعمرش وتضرب QuotaExceededError
  if (isset($data['paraveda_history_v1']['d']) && is_array($data['paraveda_history_v1']['d'])) {
    if (count($data['paraveda_history_v1']['d']) > 400) {
      $data['paraveda_history_v1']['d'] = array_slice($data['paraveda_history_v1']['d'], 0, 400);
    }
  }
  unset($data['paraveda_backup_v1']);
  unset($data['paraveda_backup_v1_agents']);

  $__body = json_encode($data, JSON_UNESCAPED_UNICODE);
  $__etag = '"' . md5($__body) . '"';
  crm_etag_store($__sig, $__etag);
  header('ETag: ' . $__etag);
  if ($__inm !== '' && ($__inm === $__etag || $__inm === 'W/' . $__etag)) { http_response_code(304); exit; }

  /* PERF v3.90: gzip — الداتا JSON كتضغط ~85%. 1.1MB → ~150KB. */
  if (!headers_sent() && !ini_get('zlib.output_compression')
      && strpos((string)($_SERVER['HTTP_ACCEPT_ENCODING'] ?? ''), 'gzip') !== false
      && function_exists('gzencode')) {
    $__gz = @gzencode($__body, 5);
    if ($__gz !== false) {
      header('Content-Encoding: gzip');
      header('Vary: Accept-Encoding');
      header('Content-Length: ' . strlen($__gz));
      echo $__gz;
      exit;
    }
  }
  header('Content-Length: ' . strlen($__body));
  echo $__body;
  exit;
}

/* ---------- POST ---------- */
if ($m === 'POST') {
  if (!hash_equals($SECRET, crm_token())) crm_out(array('ok'=>false, 'err'=>'token'), 403);

  $raw = file_get_contents('php://input');
  if (strlen($raw) > $MAX_BODY) crm_out(array('ok'=>false, 'err'=>'too-large'), 413);
  $b = json_decode($raw, true);
  if (!is_array($b)) crm_out(array('ok'=>false, 'err'=>'bad-json'), 400);

  /* -- actions (Digylog etc.) -- */
  if (isset($b['action'])) {
    $a = (string)$b['action'];
    if ($a === 'ping') crm_out(array('ok'=>true, 'v'=>'3.83'));
    if ($a === 'restore') crm_out(array('ok'=>false, 'err'=>'restore-not-implemented', 'msg'=>'الاسترجاع كيدار يدوياً من مجلد backups'), 501);
    if ($a === 'sheet_orders') crm_sheet_orders($b);   // v3.97: الشيت → CRM
    if ($a === 'push_subscribe') crm_push_subscribe($b);   // v3.98
    if ($a === 'push_test') crm_push_test($b);             // v3.98
    if ($a === 'quick_order') crm_quick_order($b);         // v3.100: طلبية سريعة من البنت
    if ($a === 'digylog_admin') crm_dl_admin($b);          // v3.101: إعدادات Digylog (أدمين)
    if (strpos($a, 'digylog') === 0) crm_out(array('ok'=>false, 'err'=>'digylog-removed', 'msg'=>'الربط مع Digylog تحيد فـ v3.41'), 410);
    crm_out(array('ok'=>false, 'err'=>'unknown-action'), 400);
  }

  /* -- normal key write -- */
  if (!isset($b['key']) || !array_key_exists('d', $b)) crm_out(array('ok'=>false, 'err'=>'bad-body'), 400);
  $k = (string)$b['key'];
  if (strpos($k, 'afrizon_') === 0) $k = 'paraveda_' . substr($k, 8); // old tabs
  if (!in_array($k, $ALLOWED_KEYS, true)) { crm_audit("reject | key=$k | not-allowed"); crm_out(array('ok'=>false, 'err'=>'key-not-allowed'), 400); }
  // v3.83: paraveda_backup_v1 ملغية لحماية كاش المتصفح من الامتلاء
  if ($k === 'paraveda_backup_v1' || $k === 'paraveda_backup_v1_agents') {
    // FIX v3.90: $t كانت كتستعمل قبل ما تتعرّف (notice + t=null فالجواب)
    crm_out(array('ok'=>true, 'noop'=>'backup_deprecated', 't'=>(int)(microtime(true) * 1000)));
  }

  $d = crm_unwrap($b['d']);
  $t = isset($b['t']) ? (int)$b['t'] : (int)(microtime(true) * 1000);
  $now = (int)(microtime(true) * 1000);
  if ($t > $now + 60000) $t = $now; // clock skew guard

  // v3.62: reset epoch — writes of wiped keys carrying data older than the reset are ignored
  // v3.67: EXCEPT for reset-aware clients — the body now carries rs (the client's seen reset
  // stamp). A device that acknowledged the reset can never silently lose its NEW orders again,
  // even if its clock is behind (client _u < RESET_T was wrongly discarding genuine new rows).
  $__cur0 = crm_read_raw();
  $RESET_T = isset($__cur0['paraveda_reset_v1']['t']) ? (int)$__cur0['paraveda_reset_v1']['t'] : 0;
  $RS = isset($b['rs']) ? (int)$b['rs'] : 0;
  $RESET_AWARE = ($RESET_T > 0 && $RS >= $RESET_T);
  $RESET_KEYS = array('paraveda_catalog_v1','sheet_pièce','paraveda_history_v1','paraveda_adspend_v1','paraveda_perfrows_v1','paraveda_backup_v1');
  if ($RESET_T > 0 && !$RESET_AWARE && in_array($k, $RESET_KEYS, true) && $t < $RESET_T) { crm_audit("reset-stale | key=$k | t=$t < reset=$RESET_T"); crm_out(array('ok'=>true, 'noop'=>'reset-stale', 'reset'=>$RESET_T, 't'=>$RESET_T)); }
  if ($k === 'paraveda_orders_v5' && $RESET_T > 0 && !$RESET_AWARE && is_array($d)) {
    $__f = array(); foreach ($d as $o) { if (is_array($o) && isset($o['_u']) && (float)$o['_u'] >= $RESET_T) $__f[] = $o; }
    $d = $__f;
  }
  // ghost guard: never let a client wipe orders/users with an empty array while server has data
  /* v3.91: zidt paraveda_adspend_v1 — دابا Google Sheet كيقدر يكتب هنا،
   * وإلا تمسحات الورقة بالغلط (ولا سكريبت طاح فنص الطريق) ما خاصش
   * المصاريف كاملين يطيرو من الـCRM. */
  if (($k === 'paraveda_orders_v5' || $k === 'paraveda_users_v1' || $k === 'paraveda_villes_v2' || $k === 'paraveda_chat_v1' || $k === 'paraveda_catalog_v1' || $k === 'paraveda_adspend_v1' || $k === 'paraveda_backup_v1' || $k === 'paraveda_backup_v1_agents') && is_array($d) && count($d) === 0) {
    $cur = $__cur0;   // PERF v3.90: كنعاودو نستعملو القراية ديال فوق عوض قراية جديدة ديال 2.2MB
    if (isset($cur[$k]['d']) && is_array($cur[$k]['d']) && count($cur[$k]['d']) > 0) {
      crm_audit("ghost | key=$k | empty write blocked");
      crm_out(array('ok'=>true, 'noop'=>'ghost', 't'=>(int)$cur[$k]['t']));
    }
  }

  $fh = @fopen($LOCK_FILE, 'c');
  if ($fh) @flock($fh, LOCK_EX);

  // PERF v3.90: هادي الوحيدة لي خاصها تكون طرية — ممكن شي request آخر كتب
  // قبل ما ناخدو القفل. الجوج القرايات ديال فوق كيتشاركو نفس الـ cache.
  $data = crm_read_raw(true);
  $prevT = isset($data[$k]['t']) ? (int)$data[$k]['t'] : 0;

  $__NOMERGE = array('paraveda_orders_v5','paraveda_chat_v1','paraveda_users_v1','paraveda_agent_names_v1','paraveda_villes_v2','paraveda_worktimes_v1','paraveda_remarques_v1','paraveda_avances_v1','paraveda_adspend_v1','paraveda_perfrows_v1','paraveda_livraison_v1','paraveda_history_v1','paraveda_catalog_v1','tabs_list_v1','sheet_pièce');
  if ($t < $prevT && !in_array($k, $__NOMERGE, true)) { // stale write — غير على ليستة ما كيندمجوش
    if ($fh) { @flock($fh, LOCK_UN); @fclose($fh); }
    crm_audit("stale | key=$k | t=$t < $prevT");
    crm_out(array('ok'=>true, 'noop'=>'stale', 't'=>$prevT));
  }
  $prevJson = isset($data[$k]['d']) ? json_encode($data[$k]['d'], JSON_UNESCAPED_UNICODE) : null;
  $newJson  = json_encode($d, JSON_UNESCAPED_UNICODE);
  if ($prevJson === $newJson) {          // nothing changed: touch time only, no backup churn
    /* v3.81: t ما كينقصش عمرو — قبل، جهاز ساعتو متأخرة كان كيرجّع t للور
       → الأجهزة الأخرى كيوقفو يشوفو التبدلات (i.t > c كتفشل ديما). */
    $effT = max($prevT, $t);
    $data[$k]['t'] = $effT;
    crm_write_all($data);
    if ($fh) { @flock($fh, LOCK_UN); @fclose($fh); }
    crm_out(array('ok'=>true, 'noop'=>'same', 't'=>$effT));
  }

  crm_backup();
  // v3.45: orders are merged row-by-row (newest _u wins, rows never dropped) so
  // several agents/admins writing at the same time never erase each other.
  if ($k === 'paraveda_orders_v5' && is_array($d)) {
    $__storedO = (isset($data[$k]['d']) && is_array($data[$k]['d'])) ? crm_unwrap($data[$k]['d']) : null;   // v3.81: unwrap قبل الدمج
    if (is_array($__storedO)) $d = crm_merge_orders($__storedO, $d, $RESET_T);
    // PERF v3.90: تنقية الطلبيات الممسوحة القديمة (أكثر من 30 يوم) — كانو 42% من الداتا
    $d = crm_purge_tombstones($d, $TOMBSTONE_TTL, $TOMBSTONE_MAX);
  }
  // v3.72: الرسائل كيتدمجو union بالـ id (ما كاينش مسح فالشات) — كاتب متزامنين ما يضيعوش رسائل
  if ($k === 'paraveda_chat_v1' && is_array($d)) {
    $__storedC = (isset($data[$k]['d']) && is_array($data[$k]['d'])) ? crm_unwrap($data[$k]['d']) : null;   // v3.81: unwrap قبل الدمج
    if (!is_array($__storedC)) $__storedC = array();
    $byId = array();
    foreach ($__storedC as $m) { if (is_array($m) && isset($m['id'])) $byId[(string)$m['id']] = $m; }
    foreach ($d as $m) {
      if (!is_array($m) || !isset($m['id'])) continue;
      $id = (string)$m['id'];
      if (isset($byId[$id])) { $byId[$id]['read'] = !empty($byId[$id]['read']) || !empty($m['read']); }
      else $byId[$id] = $m;
    }
    usort($byId, function($x, $y) { $a = (float)$x['id']; $b = (float)$y['id']; return $a == $b ? 0 : ($a < $b ? -1 : 1); });
    $d = array_values($byId);
  }
  // v3.79: اليوزرز — دمج بالصفوف (نفس حل الطلبيات): _u الأحدث كيربح، الحذف _del ناعم.
  // حتى دفع قديم ولا ساعة متقدمة ما بقاش يقدر يمسح يوزر مضاف.
  // v3.81: unwrap على الداتا المخزنة قبل الدمج — غلاف مزدوج قديم كان كيخلي
  // الدمج كيبدا من ليستة خاوية → اليوزرز كلهم كيتمسحو بلا ما حد يحس.
  if ($k === 'paraveda_users_v1' && is_array($d)) {
    $__storedU = (isset($data[$k]['d']) && is_array($data[$k]['d'])) ? crm_unwrap($data[$k]['d']) : null;
    if (is_array($__storedU)) {
      $uById = array();
      foreach ($__storedU as $u) { if (is_array($u) && isset($u['id'])) $uById[(string)$u['id']] = $u; }
      $nowms2 = (int)(microtime(true) * 1000);
      foreach ($d as $u) {
        if (!is_array($u) || !isset($u['id'])) continue;
        if (isset($u['_u']) && (float)$u['_u'] > $nowms2) $u['_u'] = $nowms2;
        $uid = (string)$u['id'];
        if (!isset($uById[$uid])) {
          /* v3.81: نفس الاسم ما كيتزادش مرتين بجوج ids — جوج أجهزة زادو نفس
             اليوزر فنفس الوقت كانو كيديرو دوبلون. اللي كاين فالسيرفر كيبقى. */
          $un = (isset($u['username']) && is_string($u['username'])) ? strtolower(trim($u['username'])) : '';
          $dup = false;
          if ($un !== '') { foreach ($uById as $su) { if (empty($su['_del']) && isset($su['username']) && is_string($su['username']) && strtolower(trim((string)$su['username'])) === $un) { $dup = true; break; } } }
          if (!$dup) $uById[$uid] = $u;
          continue;
        }
        /* v3.82: الحذف نهائي (من الجوج جيهات): نسخة فيها _del كتربح دايماً،
           حتى إلا كانت _u ديالها أقدم — يوزر ممسوح ما كيرجعش. */
        $sd = !empty($uById[$uid]['_del']); $id2 = !empty($u['_del']);
        if ($sd || $id2) {
          $cu = isset($uById[$uid]['_u']) ? (float)$uById[$uid]['_u'] : 0;
          $nu = isset($u['_u']) ? (float)$u['_u'] : 0;
          if (!$sd || ($id2 && $nu > $cu)) $uById[$uid] = $u;
          continue;
        }
        $cu = isset($uById[$uid]['_u']) ? (float)$uById[$uid]['_u'] : 0;
        $nu = isset($u['_u']) ? (float)$u['_u'] : 0;
        if ($nu > $cu) $uById[$uid] = $u;
      }
      $d = array_values($uById);
    }
  }
  // v3.78: دمج موحد — الوكلاء/المدن/غيرهم
  if (in_array($k, $__NOMERGE, true) && $k !== 'paraveda_orders_v5' && $k !== 'paraveda_chat_v1' && $k !== 'paraveda_users_v1'
      && is_array($d)) {
    $__storedL = (isset($data[$k]['d']) && is_array($data[$k]['d'])) ? crm_unwrap($data[$k]['d']) : null;    // v3.81: unwrap قبل الدمج
    if (is_array($__storedL)) $d = crm_merge_list($__storedL, $d, $prevT, $t);
  }
  // v3.83: حصر السجل فـ 400 عملية الأخيرة كحد أقصى
  if ($k === 'paraveda_history_v1' && is_array($d)) {
    usort($d, function($x, $y) {
      $atX = (is_array($x) && isset($x['at'])) ? (string)$x['at'] : '';
      $atY = (is_array($y) && isset($y['at'])) ? (string)$y['at'] : '';
      $c = strcmp($atY, $atX);
      if ($c !== 0) return $c;
      $idX = (is_array($x) && isset($x['id'])) ? (float)$x['id'] : 0;
      $idY = (is_array($y) && isset($y['id'])) ? (float)$y['id'] : 0;
      return $idX == $idY ? 0 : ($idX < $idY ? 1 : -1);
    });
    if (count($d) > 400) {
      $d = array_slice($d, 0, 400);
    }
  }
  $pushBy = ($k === 'paraveda_orders_v5' && is_array($d)) ? crm_push_collect_changes(isset($data[$k]['d']) ? $data[$k]['d'] : array(), $d, $now) : array();
  $data[$k] = array('t' => max($prevT + 1, $t), 'd' => $d);   // v3.81: t رتيب ديما — كتابة جديدة كيشوفها كلشي حتى من جهاز ساعتو متأخرة
  $effT = $data[$k]['t'];
  $ok = crm_write_all($data);
  if ($ok && is_array($d)) crm_journal_append($k, $effT, $d);
  if ($fh) { @flock($fh, LOCK_UN); @fclose($fh); }

  if (!$ok) crm_out(array('ok'=>false, 'err'=>'write-failed'), 500);
  crm_audit("write | $k | t=$effT | bytes=" . strlen($newJson));
  if (!empty($pushBy)) { try { crm_push_batch($pushBy); } catch (Throwable $__e) { crm_audit('push-error | ' . $__e->getMessage()); } }   // v3.99
  crm_out(array('ok'=>true, 't'=>$effT));
}

http_response_code(405);
echo '{"ok":false,"err":"method-not-allowed"}';
exit;